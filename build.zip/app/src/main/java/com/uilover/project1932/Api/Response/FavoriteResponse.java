package com.uilover.project1932.Api.Response;

public class FavoriteResponse {
    public Integer id;
    public String workoutTitle;
    public Long addedDate;
}

