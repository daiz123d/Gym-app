package com.uilover.project1932.Api.Response;

public class WorkoutHistoryResponse {
    public Integer id;
    public String workoutTitle;
    public Long completionDate;
    public String duration;
    public Integer kcalBurned;
    public Integer completedLessons;
    public Integer totalLessons;
}

