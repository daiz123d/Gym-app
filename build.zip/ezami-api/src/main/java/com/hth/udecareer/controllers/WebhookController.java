package com.hth.udecareer.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hth.udecareer.model.dto.RevenueCatWebhookDto;
import com.hth.udecareer.model.response.ApiResponse;
import com.hth.udecareer.service.Impl.RevenueCatWebhookService;
import io.swagger.v3.oas.annotations.Hidden;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/webhook")
@RequiredArgsConstructor
@Hidden
public class WebhookController {

    private final RevenueCatWebhookService revenueCatWebhookService;
    private final ObjectMapper objectMapper;

    @PostMapping("/revenuecat")
    public ResponseEntity<?> handleRevenueCatWebhook(
            @RequestBody String payload,
            @RequestHeader(value = "X-RevenueCat-Signature", required = false) String signature) {

        log.info("Received RevenueCat webhook");

        try {
            if (signature != null && !revenueCatWebhookService.verifyWebhookSignature(payload, signature)) {
                log.error("Invalid webhook signature");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid signature");
            }

            RevenueCatWebhookDto.WebhookEvent event = objectMapper.readValue(
                    payload,
                    RevenueCatWebhookDto.WebhookEvent.class
            );

            revenueCatWebhookService.processWebhookEvent(event);

            return ResponseEntity.ok().build();

        } catch (Exception e) {
            log.error("Error processing webhook", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error: " + e.getMessage());
        }
    }

    @GetMapping("/revenuecat/ping")
    public ApiResponse ping() {
        return ApiResponse.success("RevenueCat webhook endpoint is active");
    }
}