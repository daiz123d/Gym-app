package com.hth.udecareer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hth.udecareer.entities.PostMeta;

@Repository
public interface PostMetaRepository extends JpaRepository<PostMeta, Long> {

    List<PostMeta> findAllByPostIdInAndMetaKey(List<Long> postIds, String metaKey);

    PostMeta findByPostIdAndMetaKey(Long postId, String metaKey);
}
