package com.hth.udecareer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hth.udecareer.entities.UserActivityMetaEntity;

@Repository
public interface UserActivityMetaRepository extends JpaRepository<UserActivityMetaEntity, Long> {

    List<UserActivityMetaEntity> findAllByActivityIdIn(List<Long> activityIds);
}
