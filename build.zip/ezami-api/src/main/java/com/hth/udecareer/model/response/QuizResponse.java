package com.hth.udecareer.model.response;

import com.hth.udecareer.model.dto.QuizDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Schema(description = "Thông tin bài quiz/bài kiểm tra")
public class QuizResponse {
    @Schema(description = "ID duy nhất của quiz", example = "123")
    private Long id;

    @Schema(description = "Slug của quiz (dùng cho URL )", example = "toeic-reading-test-1")
    private String slug;

    @Schema(description = "Thời gian giới hạn làm bài (phút)", example = "60")
    private Integer timeLimit;

    @Schema(description = "Tổng số câu hỏi trong quiz", example = "100")
    private Long questions;

    @Schema(description = "Phần trăm điểm tối thiểu để đạt (pass)", example = "70")
    private Integer passingPercentage;

    @Schema(description = "Số câu hỏi người dùng đã trả lời", example = "95")
    private Long answeredQuestions;

    @Schema(description = "Tổng điểm người dùng đã đạt được", example = "850")
    private Long answeredPoints;

    @Schema(description = "Tổng điểm tối đa của quiz", example = "990")
    private Long totalPoints;

    @Schema(description = "Phần trăm điểm đạt được", example = "85.85")
    private Double percentage;

    @Schema(description = "Số câu trả lời đúng", example = "85")
    private Long answeredCorrects;

    @Schema(description = "Điểm số người dùng đạt được", example = "850")
    private Long answeredScore;

    @Schema(description = "Trạng thái đã đạt hay chưa (1: đạt, 0: chưa đạt)", example = "1")
    private Long pass;

    @Schema(description = "Tên của quiz", example = "TOEIC Reading Practice Test 1")
    private String name;

    @Schema(description = "ID của bài post liên quan", example = "456")
    private Long postId;

    @Schema(description = "Nội dung HTML của bài post", example = "<p>Đây là bài test TOEIC Reading...</p>")
    private String postContent;

    @Schema(description = "Tiêu đề của bài post", example = "TOEIC Reading Practice Test 1")
    private String postTitle;

    public static QuizResponse from(QuizDto quizDto) {
        return builder()
                .id(quizDto.getId())
                .slug(quizDto.getSlug())
                .timeLimit(quizDto.getTimeLimit())
                .name(quizDto.getName())
                .postId(quizDto.getPostId())
                .postContent(quizDto.getPostContent())
                .postTitle(quizDto.getPostTitle())
                .build();
    }
}
