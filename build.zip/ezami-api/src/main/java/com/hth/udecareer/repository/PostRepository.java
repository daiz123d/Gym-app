package com.hth.udecareer.repository;

import com.hth.udecareer.entities.Post;
import com.hth.udecareer.entities.TermEntity;
import com.hth.udecareer.enums.PostStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository
public interface PostRepository extends JpaRepository<Post, Long> {

    List<Post> findAllByStatusAndType(PostStatus status, String type);

    @Query("SELECT pt FROM Post pt, TermRelationshipEntity trp, TermTaxonomyEntity tty " +
            "WHERE pt.id = trp.id.objectId AND trp.id.termTaxonomyId = tty.id " +
            "AND tty.taxonomy = 'category' " +
            "AND tty.termId = :categoryId " +
            "AND pt.status in :postStatues " +
            "ORDER BY pt.date")
    List<Post> findByCategoryId(@Param("categoryId") Long categoryId,
                                @Param("postStatues") List<PostStatus> postStatuses);

    @Query("SELECT tm FROM TermEntity tm, TermTaxonomyEntity tty " +
            "WHERE tm.id = tty.termId " +
            "AND tty.taxonomy = 'category' " +
            "AND tm.slug in :slugs")
    List<TermEntity> findCategoryBySlug(@Param("slugs") Collection<String> slugs);
}
