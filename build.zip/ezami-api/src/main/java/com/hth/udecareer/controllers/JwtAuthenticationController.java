package com.hth.udecareer.controllers;

import javax.validation.Valid;

import com.hth.udecareer.enums.ErrorCode;
import com.hth.udecareer.model.request.CheckVerificationCodeRequest;
import com.hth.udecareer.service.VerificationCodeService;

import com.hth.udecareer.entities.User;
import com.hth.udecareer.service.Impl.GoogleAuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.util.UriComponentsBuilder;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

import com.hth.udecareer.exception.AppException;
import com.hth.udecareer.model.request.RegisterRequest;
import com.hth.udecareer.model.request.RegisterWithCodeRequest;
import com.hth.udecareer.model.request.VerificationRequest;
import com.hth.udecareer.model.response.UserResponse;
import com.hth.udecareer.security.JwtRequest;
import com.hth.udecareer.security.JwtResponse;
import com.hth.udecareer.security.JwtTokenUtil;
import com.hth.udecareer.security.JwtUserDetailsService;
import com.hth.udecareer.service.UserService;
import com.hth.udecareer.config.GoogleOAuthConfig;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;
import java.net.URI;

@Slf4j
@RestController
@RequiredArgsConstructor
@Tag(name = "Authentication & User Management")
public class JwtAuthenticationController {

        private final AuthenticationManager authenticationManager;
        private final JwtTokenUtil jwtTokenUtil;
        private final JwtUserDetailsService userDetailsService;
        private final UserService userService;

        private final VerificationCodeService verificationCodeService;

        private final GoogleAuthService googleAuthService;
        private final GoogleOAuthConfig googleOAuthConfig;

        @Operation(summary = "Authenticate user (Login)", description = "Generates a JWT token for a valid user.")
        @ApiResponses(value = {
                        @ApiResponse(responseCode = "200", description = "Authentication successful", content = @Content(schema = @Schema(implementation = JwtResponse.class))),
                        @ApiResponse(responseCode = "401", description = "Invalid credentials", content = @Content),
                        @ApiResponse(responseCode = "403", description = "User is disabled", content = @Content),
                        @ApiResponse(responseCode = "default", description = "Unexpected error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
        })
        @PostMapping("/authenticate")
        public JwtResponse createAuthenticationToken(@Valid @RequestBody JwtRequest authenticationRequest)
                        throws Exception {
                log.info("createAuthenticationToken: user {}", authenticationRequest.getUsername());
                authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());

                final UserDetails userDetails = userDetailsService
                                .loadUserByUsername(authenticationRequest.getUsername());

                final String token = jwtTokenUtil.generateToken(userDetails);

                return new JwtResponse(token);
        }

        @Operation(summary = "Sign up a new user (Legacy)", description = "Registers a new user.")
        @ApiResponses(value = {
                        @ApiResponse(responseCode = "200", description = "User registered successfully", content = @Content(schema = @Schema(implementation = UserResponse.class))),
                        @ApiResponse(responseCode = "400", description = "Invalid request data or user already exists"),
                        @ApiResponse(responseCode = "default", description = "Unexpected error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
        })
        @PostMapping("/signup")
        public UserResponse signup(@RequestBody @Valid RegisterRequest request) throws Exception {
                log.info("signup: user {}, appCode {}", request.getEmail(), request.getAppCode());
                return userService.signup(request);
        }

        @Operation(summary = "Sign up a new user with verification code", description = "Registers a new user after code verification.")
        @ApiResponses(value = {
                        @ApiResponse(responseCode = "200", description = "User registered successfully", content = @Content(schema = @Schema(implementation = UserResponse.class))),
                        @ApiResponse(responseCode = "400", description = "Invalid request data or invalid code"),
                        @ApiResponse(responseCode = "default", description = "Unexpected error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
        })
        @PostMapping("/register")
        public UserResponse signup(@Valid @RequestBody RegisterWithCodeRequest request) throws Exception {
                log.info("register: user {}, appCode {}", request.getEmail(), request.getAppCode());
                return userService.signup(request);
        }

        @Operation(summary = "Generate verification code", description = "Sends a verification code to the user's email for registration or password reset.")
        @ApiResponses(value = {
                        @ApiResponse(responseCode = "200", description = "Code sent successfully"),
                        @ApiResponse(responseCode = "400", description = "Invalid email or type"),
                        @ApiResponse(responseCode = "default", description = "Unexpected error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
        })
        @PostMapping("/verification-code")
        public void generateVerificationCode(@Valid @RequestBody VerificationRequest request) throws Exception {
                log.info("generateVerificationCode: user {}, type {}", request.getEmail(), request.getType());
                userService.generateVerificationCode(request.getEmail(), request.getType());
        }

        @Operation(summary = "Check verification code", description = "Validates the provided verification code.")
        @ApiResponses(value = {
                        @ApiResponse(responseCode = "200", description = "Code is valid"),
                        @ApiResponse(responseCode = "400", description = "Invalid, incorrect, or expired code"),
                        @ApiResponse(responseCode = "default", description = "Unexpected error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
        })
        @PostMapping("/verification-code/check")
        public void checkVerificationCode(@Valid @RequestBody CheckVerificationCodeRequest request)
                        throws AppException {
                log.info("checkVerificationCode: email {}, type {}", request.getEmail(), request.getType());
                verificationCodeService.checkVerificationCode(request.getEmail(), request.getVerificationCode(),
                                request.getType());
        }

        private void authenticate(String username, String password) throws Exception {
                // Uniformly treat blank/null username or password as invalid credentials
                if (StringUtils.isBlank(username) || StringUtils.isBlank(password)) {
                        throw new AppException(ErrorCode.INVALID_CREDENTIALS);
                }
                try {
                        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
                } catch (DisabledException e) {
                        log.error("User {} disabled", username);
                        throw new AppException(ErrorCode.USER_DISABLED);
                } catch (UsernameNotFoundException e) {
                        log.error("User not found: {}", username);
                        // Treat as invalid credentials for security - don't leak username existence
                        throw new AppException(ErrorCode.INVALID_CREDENTIALS);
                } catch (BadCredentialsException e) {
                        log.error("Invalid credentials for user {}", username);
                        throw new AppException(ErrorCode.INVALID_CREDENTIALS);
                }
        }

        @Operation(
                summary = "Get Google auth URL", 
                description = """
                        **Lấy URL đăng nhập Google OAuth 2.0**
                        
                        API này tạo ra một URL để redirect người dùng đến trang đăng nhập Google.
                        
                        **Flow:**
                        1. Client gọi API này để lấy authorizationUrl
                        2. Redirect người dùng đến URL đó
                        3. Sau khi đăng nhập Google, user sẽ được redirect về callback URL
                        4. Server xử lý callback và trả về JWT token
                        
                        **Dành cho:** Web applications
                        """
        )
        @ApiResponses(value = {
                        @ApiResponse(responseCode = "200", description = "URL được tạo thành công"),
                        @ApiResponse(responseCode = "default", description = "Lỗi không mong đợi", content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
        })
        @GetMapping("/auth/google/login")
        public ResponseEntity<Map<String, String>> getGoogleAuthUrl(
                @io.swagger.v3.oas.annotations.Parameter(
                        description = "Nền tảng gọi: 'mobile' hoặc 'web'",
                        example = "mobile"
                )
                @RequestParam(name = "platform", defaultValue = "web") String platform
        ) {
            log.info("Request for Google auth URL for platform: {}", platform);

            // Truyền "platform" (ví dụ: "mobile") làm state
            String authUrl = googleAuthService.generateGoogleAuthUrl(platform);

            Map<String, String> response = new HashMap<>();
            response.put("authorizationUrl", authUrl);
            return ResponseEntity.ok(response);
        }

    @Operation(
            summary = "Google auth callback (Web)",
            description = """
                        **Xử lý callback từ Google sau khi xác thực**
                        
                        API này được Google gọi tự động sau khi người dùng đăng nhập thành công.
                        
                        **Flow:**
                        1. Người dùng đăng nhập Google thành công
                        2. Google redirect về URL này với authorization code
                        3. Server đổi code lấy user info từ Google
                        4. Tạo hoặc tìm user trong database
                        5. Trả về JWT token
                        
                        **Dành cho:** Web applications (callback URL)
                        """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Đăng nhập Google thành công, JWT được trả về", content = @Content(schema = @Schema(implementation = JwtResponse.class))),
            @ApiResponse(responseCode = "400", description = "Code Google không hợp lệ hoặc lỗi callback"),
            @ApiResponse(responseCode = "default", description = "Lỗi không mong đợi", content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
    })
    @GetMapping("/auth/google/callback")
    public ResponseEntity<?> handleGoogleCallback(
            @RequestParam("code") String code,
            @RequestParam(name = "state", required = false) String platform) {
        try {
            User user = googleAuthService.processGoogleCallback(code);

            final UserDetails userDetails = userDetailsService
                    .loadUserByUsername(user.getEmail());
            final String token = jwtTokenUtil.generateToken(userDetails);

            String finalRedirectUrl;
            if ("mobile".equals(platform)) {
                finalRedirectUrl = googleOAuthConfig.getMobileSuccessUrl();
            } else {
                finalRedirectUrl = googleOAuthConfig.getWebSuccessUrl();
            }

            String redirectUrlWithToken = UriComponentsBuilder
                    .fromUriString(finalRedirectUrl)
                    .queryParam("token", token)
                    .build().toUriString();

            HttpHeaders headers = new HttpHeaders();
            headers.setLocation(URI.create(redirectUrlWithToken));
            return new ResponseEntity<>(headers, HttpStatus.FOUND); // 302 Redirect

        } catch (Exception e) {
            log.error("Lỗi trong quá trình xử lý callback của Google: {}", e.getMessage(), e);

            String errorUrl = "web".equals(platform) ?
                    googleOAuthConfig.getWebSuccessUrl() :
                    googleOAuthConfig.getMobileSuccessUrl();

            String redirectUrlWithError = UriComponentsBuilder
                    .fromUriString(errorUrl)
                    .queryParam("error", e.getMessage())
                    .build().toUriString();

            HttpHeaders headers = new HttpHeaders();
            headers.setLocation(URI.create(redirectUrlWithError));
            return new ResponseEntity<>(headers, HttpStatus.FOUND);
        }
    }
}