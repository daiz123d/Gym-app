package com.hth.udecareer.model.request;

import javax.validation.constraints.Email;

import org.springframework.lang.Nullable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Request cập nhật thông tin người dùng (tất cả field đều optional)")
public class UpdateUserInfoRequest {
    @Nullable
    @Schema(description = "Họ tên hiển thị (sẽ lưu vào displayName)", example = "Nguyễn Văn A")
    private String fullName;

    @Nullable
    @Schema(description = "Tên hiển thị (alias ưu tiên hơn fullName nếu được gửi)", example = "Nguyễn Văn A")
    private String displayName;

    @Nullable
    @Schema(description = "Biệt danh (sẽ lưu vào user_nicename)", example = "nguyenvana")
    private String niceName;

    @Nullable
    @Schema(description = "URL avatar (sẽ lưu vào user_url)", example = "https://cdn.example.com/avatars/u123.png")
    private String userUrl;

    @Nullable
    @Email
    @Schema(description = "Email (không cập nhật qua API này, nếu gửi sẽ bỏ qua)", example = "user@example.com")
    private String email;

    @Nullable
    @Schema(description = "Số điện thoại (không lưu DB, nếu gửi sẽ bỏ qua)", example = "0912345678")
    private String mobile;

    @Nullable
    @Schema(description = "Ngày sinh (không lưu DB, nếu gửi sẽ bỏ qua)", example = "1990-01-15")
    private String dob;
}
