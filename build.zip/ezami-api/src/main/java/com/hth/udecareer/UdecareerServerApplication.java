package com.hth.udecareer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UdecareerServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(UdecareerServerApplication.class, args);
    }

}
