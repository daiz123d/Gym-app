package com.hth.udecareer.service;

import static com.hth.udecareer.utils.StreamUtil.safeStream;
import static java.time.temporal.ChronoUnit.DAYS;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toMap;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;

import com.hth.udecareer.enums.ErrorCode;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.hth.udecareer.entities.PostMeta;
import com.hth.udecareer.entities.QuestionEntity;
import com.hth.udecareer.entities.QuizMaster;
import com.hth.udecareer.entities.QuizStatisticEntity;
import com.hth.udecareer.entities.QuizStatisticId;
import com.hth.udecareer.entities.QuizStatisticRefEntity;
import com.hth.udecareer.entities.User;
import com.hth.udecareer.entities.UserActivityEntity;
import com.hth.udecareer.entities.UserActivityMetaEntity;
import com.hth.udecareer.entities.UserPurchasedEntity;
import com.hth.udecareer.enums.PostStatus;
import com.hth.udecareer.exception.AppException;
import com.hth.udecareer.model.dto.PurchasedDto;
import com.hth.udecareer.model.dto.QuizDto;
import com.hth.udecareer.model.dto.RevenueCatSubscriberDto;
import com.hth.udecareer.model.request.SubmitAnswerRequest;
import com.hth.udecareer.model.request.SubmitAnswerRequest.AnsweredData;
import com.hth.udecareer.model.response.CategoryResponse;
import com.hth.udecareer.model.response.QuestionResponse;
import com.hth.udecareer.model.response.QuestionResponse.AnswerData;
import com.hth.udecareer.model.response.QuizInfoResponse;
import com.hth.udecareer.model.response.QuizResponse;
import com.hth.udecareer.model.response.SubmitAnswerResponse;
import com.hth.udecareer.repository.PostMetaRepository;
import com.hth.udecareer.repository.QuestionRepository;
import com.hth.udecareer.repository.QuizMasterRepository;
import com.hth.udecareer.repository.QuizStatisticRefRepository;
import com.hth.udecareer.repository.QuizStatisticRepository;
import com.hth.udecareer.repository.UserActivityMetaRepository;
import com.hth.udecareer.repository.UserActivityRepository;
import com.hth.udecareer.repository.UserPurchasedRepository;
import com.hth.udecareer.repository.UserRepository;
import com.hth.udecareer.utils.BooleanUtil;
import com.hth.udecareer.utils.PostMetaUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class QuizMasterService {
    private final QuizMasterRepository quizMasterRepository;
    private final QuestionRepository questionRepository;
    private final PostMetaRepository postMetaRepository;
    private final UserActivityRepository userActivityRepository;
    private final UserActivityMetaRepository userActivityMetaRepository;
    private final UserRepository userRepository;
    private final QuizStatisticRefRepository quizStatisticRefRepository;
    private final QuizStatisticRepository quizStatisticRepository;
    private final RevenueCatService revenueCatService;
    private final QuizCategoryService quizCategoryService;
    private final UserPurchasedRepository userPurchasedRepository;

    public List<QuizResponse> searchQuiz(String email, String category, String typeTest) throws AppException {
        final User user = userRepository
                .findByEmail(email)
                .orElseThrow(() -> new AppException(ErrorCode.EMAIL_USER_NOT_FOUND));

        final List<QuizDto> quizDtoList =
                quizMasterRepository.findActiveQuizzes(List.of(PostStatus.PUBLISH, PostStatus.PRIVATE),
                                "sfwd-quiz")
                        .stream()
                        .filter(quiz -> {
                            boolean flag = ObjectUtils.isEmpty(category) || quiz.isCategory(
                                    category);

                            if (!ObjectUtils.isEmpty(typeTest)) {
                                if ("mini".equals(typeTest)) {
                                    if (!quiz.isMiniTest()) {
                                        flag = false;
                                    }
                                } else {
                                    if (quiz.isMiniTest()) {
                                        flag = false;
                                    }
                                }
                            }

                            return flag;
                        })
                        .toList();
        final List<Long> postIds = quizDtoList.stream().map(QuizDto::getPostId).toList();
        final List<QuizResponse> responses = safeStream(quizDtoList).map(QuizResponse::from).toList();

        final Map<Long, List<Long>> postIdToQuestionIds =
                postMetaRepository.findAllByPostIdInAndMetaKey(postIds, "ld_quiz_questions")
                        .stream()
                        .collect(toMap(PostMeta::getPostId, x -> getQuestionIds(x.getMetaValue())));

        final List<PostMeta> postMetas = postMetaRepository.findAllByPostIdInAndMetaKey(postIds, "_sfwd-quiz");
        final Map<Long, String> postIdToQuizMeta = postMetas
                .stream()
                .collect(toMap(PostMeta::getPostId, PostMeta::getMetaValue));

        final List<UserActivityEntity> userActivityList = userActivityRepository.getLatestActivityByUserId(
                user.getId());
        final Map<Long, Long> postIdToActivityId = userActivityList.stream().collect(
                toMap(UserActivityEntity::getPostId, UserActivityEntity::getId));
        final List<UserActivityMetaEntity> userActivityMetaList =
                userActivityMetaRepository.findAllByActivityIdIn(
                        new ArrayList<>(postIdToActivityId.values()));
        final Map<Long, Map<String, String>> activityMetaMap = userActivityMetaList
                .stream()
                .collect(groupingBy(UserActivityMetaEntity::getActivityId,
                        toMap(UserActivityMetaEntity::getActivityMetaKey,
                                UserActivityMetaEntity::getActivityMetaValue)));

        final Map<Long, Long> postIdToScore = new HashMap<>();
        final Map<Long, Long> postIdToPass = new HashMap<>();
        final Map<Long, Long> statisticRefIdToPostId = new HashMap<>();
        final Map<Long, Long> postIdToPoint = new HashMap<>();
        final Map<Long, Double> postIdToPercentage = new HashMap<>();
        final Map<Long, Long> postIdToAnsweredCount = new HashMap<>();
        responses.forEach(quizResponse -> {
            final Long activityId = postIdToActivityId.get(quizResponse.getPostId());
            if (Objects.nonNull(activityId)) {
                final Map<String, String> metaMap = activityMetaMap.get(activityId);

                final Long statisticRefId = getValue(metaMap.get("statistic_ref_id"), Long.class);
                if (Objects.nonNull(statisticRefId)) {
                    statisticRefIdToPostId.put(statisticRefId, quizResponse.getPostId());
                }
                postIdToScore.put(quizResponse.getPostId(), getValue(metaMap.get("score"), Long.class));
                postIdToPass.put(quizResponse.getPostId(), getValue(metaMap.get("pass"), Long.class));
                postIdToPoint.put(quizResponse.getPostId(), getValue(metaMap.get("points"), Long.class));
                postIdToPercentage.put(quizResponse.getPostId(),
                        getValue(metaMap.get("percentage"), Double.class));
                postIdToAnsweredCount.put(quizResponse.getPostId(),
                        getValue(metaMap.get("answeredCount"), Long.class));
            }
        });

        final Multimap<Long, QuizStatisticEntity> multimap = ArrayListMultimap.create();
        final List<QuizStatisticEntity> quizStatisticEntityList =
                quizStatisticRepository.findAllById_StatisticRefIdIn(statisticRefIdToPostId.keySet());
        quizStatisticEntityList.forEach(quizStatisticEntity -> {
            final Long postId = statisticRefIdToPostId.get(quizStatisticEntity.getId().getStatisticRefId());
            multimap.put(postId, quizStatisticEntity);
        });

        final Map<Long, Long> postIdToCorrect = new HashMap<>();
        responses.forEach(quizResponse -> {
            final Collection<QuizStatisticEntity> quizStatisticEntities = multimap.get(
                    quizResponse.getPostId());

            final Long corrects = quizStatisticEntities.stream()
                    .filter(Objects::nonNull)
                    .mapToLong(QuizStatisticEntity::getCorrectCount)
                    .sum();

            postIdToCorrect.put(quizResponse.getPostId(), corrects);
        });

        responses.forEach(quizResponse -> {
            final List<Long> questionIds = postIdToQuestionIds.get(quizResponse.getPostId());
            final List<QuestionEntity> questionEntities = questionRepository.findAllByIdIn(questionIds);

            quizResponse.setQuestions(Objects.isNull(questionIds) ? 0L : questionIds.size());
            quizResponse.setTotalPoints(questionEntities.stream().mapToLong(QuestionEntity::getPoints).sum());

            final String quizMeta = postIdToQuizMeta.get(quizResponse.getPostId());
            if (Objects.nonNull(quizMeta)) {
                final Map<String, Object> quizMetaMap = PostMetaUtil.getPostMetaValues(quizMeta);
                final Object passingPercentage = quizMetaMap.get("sfwd-quiz_passingpercentage");

                if (Objects.nonNull(passingPercentage)) {
                    quizResponse.setPassingPercentage(NumberUtils.toInt(passingPercentage.toString().strip(), 0));
                }
            }

            quizResponse.setAnsweredScore(postIdToScore.get(quizResponse.getPostId()));
            quizResponse.setAnsweredPoints(postIdToPoint.get(quizResponse.getPostId()));
            quizResponse.setAnsweredCorrects(postIdToCorrect.get(quizResponse.getPostId()));
            quizResponse.setPass(postIdToPass.get(quizResponse.getPostId()));
            quizResponse.setPercentage(postIdToPercentage.get(quizResponse.getPostId()));
            quizResponse.setAnsweredQuestions(postIdToAnsweredCount.get(quizResponse.getPostId()));
            if (quizResponse.getAnsweredQuestions() == null) {
                quizResponse.setAnsweredQuestions(quizResponse.getAnsweredPoints());
            }
        });

        return responses;
    }

    @Nullable
    private static <T extends Number> T getValue(String str, Class<T> type) {
        try {
            if (type.equals(Long.class)) {
                return (T) Long.valueOf(str);
            } else if (type.equals(Double.class)) {
                return (T) Double.valueOf(str);
            }
        } catch (Exception ex) {
            log.warn(ex.getMessage(), ex);
        }
        return null;
    }

    public QuizInfoResponse getQuizInfo(String email, @NotNull Long quizId) throws Exception {
        final QuizMaster quizMaster = quizMasterRepository
                .findById(quizId)
                .orElseThrow(() -> new AppException(ErrorCode.QUIZ_NOT_FOUND));

        final QuizDto quizDto = quizMasterRepository
                .findActiveQuizById(quizId, List.of(PostStatus.PUBLISH, PostStatus.PRIVATE))
                .orElseThrow(() -> new AppException(ErrorCode.QUIZ_NOT_FOUND));

        final User user = userRepository
                .findByEmail(email)
                .orElseThrow(() -> new AppException(ErrorCode.EMAIL_USER_NOT_FOUND));
        if (!isPermission(user.getEmail(), user.getId(), quizDto)) {
            return QuizInfoResponse.from(quizDto);
        }

        List<QuestionEntity> questionEntities = Collections.emptyList();
        final List<Long> questionsIds = getQuestionIds(quizDto.getPostId());
        if (!CollectionUtils.isEmpty(questionsIds)) {
            questionEntities = questionRepository.findAllByIdIn(questionsIds);
        }

        final List<QuestionResponse> questionResponses = questionEntities
                .stream()
                .map(item -> QuestionResponse.from(item, quizMaster.getAnswerRandom()))
                .collect(Collectors.collectingAndThen(Collectors.toCollection(ArrayList::new),
                        list -> {
                            if (BooleanUtil.isTrue(quizMaster.getQuestionRandom())) {
                                Collections.shuffle(list);
                            }
                            return list;
                        }));

        return QuizInfoResponse.from(quizDto, questionResponses);
    }

    private boolean isPermission(@NotNull final String email,
                                 @NotNull final Long userId,
                                 @NotNull final QuizDto quizDto) {
        try {
            if (quizDto.isMiniTest()) {
                return true;
            }

            final PurchasedDto purchasedDto = getPurchasedInfo(email, userId, quizDto);
            log.info("userId: {}, quiz: {}, purchasedInfo {}", userId, quizDto.getName(), purchasedDto.toString());
            if (purchasedDto.isPurchased()
                    && (Objects.isNull(purchasedDto.getRemainDays()) || purchasedDto.getRemainDays() > 0)) {
                return true;
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
        return false;
    }

    private PurchasedDto getPurchasedInfo(@NotNull final String email,
                                          @NotNull final Long userId,
                                          @NotNull final QuizDto quizDto) {
        final Optional<CategoryResponse> optionalCategory = quizCategoryService.getCategory(quizDto);
        if (optionalCategory.isEmpty()) {
            return PurchasedDto.empty();
        }
        final CategoryResponse category = optionalCategory.get();

        final PurchasedDto purchasedInfoFromDatabase = getPurchasedInfoFromDatabase(userId, email, category.getCode());
        final PurchasedDto purchasedInfoFromRevenue = getPurchasedInfoFromRevenue(email, category);

        final boolean isPurchased = purchasedInfoFromDatabase.isPurchased() || purchasedInfoFromRevenue.isPurchased();
        final Long remainDays;
        if (Objects.isNull(purchasedInfoFromDatabase.getRemainDays())) {
            remainDays = null;
        } else {
            remainDays = Long.max(purchasedInfoFromDatabase.getRemainDays(), purchasedInfoFromRevenue.getRemainDays());
        }
        return PurchasedDto.from(isPurchased, remainDays);
    }

    private PurchasedDto getPurchasedInfoFromRevenue(@NotNull final String email,
                                                     @NotNull final CategoryResponse category) {
        long daysBetweenValue = 0L;
        boolean isPurchased = false;
        try {
            final String appUserId = DigestUtils.md5Hex(email);
            final Optional<RevenueCatSubscriberDto> optRevenueCatSubscriber = revenueCatService.getSubscriber(appUserId);
            if (optRevenueCatSubscriber.isEmpty()) {
                return PurchasedDto.empty();
            }
            final RevenueCatSubscriberDto revenueCatSubscriber = optRevenueCatSubscriber.get();

            final String entitlement = StringUtils.isNotBlank(category.getEntitlement()) ? category.getEntitlement()
                    : ("ez_" + category.getCode().toLowerCase());
            final RevenueCatSubscriberDto.Entitlement entitlementObj = revenueCatSubscriber.getSubscriber()
                    .getEntitlements().get(entitlement);

            if (Objects.nonNull(entitlementObj)) {
                isPurchased = true;

                final LocalDateTime expirationDate;
                if (Objects.nonNull(entitlementObj.getExpiresDate())) {
                    expirationDate = entitlementObj.getExpiresDate();
                } else {
                    final LocalDateTime latestPurchaseDate = entitlementObj.getPurchaseDate();
                    final String productSku = entitlementObj.getProductIdentifier();
                    final String subscriptionDaysStr = StringUtils.substringAfterLast(productSku, "_");

                    final int subDays = Objects.nonNull(subscriptionDaysStr) ? Integer.parseInt(subscriptionDaysStr) : 0;

                    expirationDate = latestPurchaseDate.plusDays(subDays);
                }

                final LocalDateTime now = LocalDateTime.now();
                daysBetweenValue = now.equals(expirationDate) ? 0 : (DAYS.between(now, expirationDate) + 1);
                daysBetweenValue = daysBetweenValue <= 0 ? 0 : daysBetweenValue;
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
        return PurchasedDto.from(isPurchased, daysBetweenValue);
    }

    private PurchasedDto getPurchasedInfoFromDatabase(@NotNull final Long userId,
                                                      @NotNull final String userEmail,
                                                      @NotNull final String categoryCode) {
        final List<UserPurchasedEntity> userPurchasedList =
                userPurchasedRepository.findAllByUserIdOrUserEmail(userId, userEmail);
        final Map<String, UserPurchasedEntity> categoryToPurchased =
                userPurchasedList.stream()
                        .collect(toMap(UserPurchasedEntity::getCategoryCode,
                                Function.identity(), (o1, o2) -> o2));
        UserPurchasedEntity purchasedEntity = categoryToPurchased.get(categoryCode);
        if (purchasedEntity == null) {
            purchasedEntity = categoryToPurchased.get("all");
        }
        Long daysBetweenValue = 0L;
        boolean isPurchased = false;
        if (purchasedEntity != null
                && Objects.nonNull(purchasedEntity.getIsPurchased())
                && purchasedEntity.getIsPurchased() > 0) {
            final LocalDateTime currTime = LocalDateTime.now();

            if (Objects.isNull(purchasedEntity.getFromTime())
                    || currTime.isAfter(purchasedEntity.getFromTime())) {
                if (Objects.isNull(purchasedEntity.getToTime())
                        || currTime.isBefore(purchasedEntity.getToTime())) {

                    isPurchased = true;
                    if (Objects.isNull(purchasedEntity.getToTime())) {
                        daysBetweenValue = null;
                    } else {
                        daysBetweenValue = DAYS.between(currTime, purchasedEntity.getToTime()) + 1;
                        daysBetweenValue = daysBetweenValue <= 0 ? 0 : daysBetweenValue;
                    }
                }
            }
        }

        return PurchasedDto.from(isPurchased, daysBetweenValue);
    }

    private List<Long> getQuestionIds(final Long postId) {
        final PostMeta postMeta = postMetaRepository.findByPostIdAndMetaKey(postId, "ld_quiz_questions");
        return getQuestionIds(postMeta.getMetaValue());
    }

    private static List<Long> getQuestionIds(final String questionIdsValue) {
        final Pattern pattern = Pattern.compile("i:(\\d+);");
        if (questionIdsValue != null) {
            final List<Long> questionsIds = new ArrayList<>();
            final Matcher matcher = pattern.matcher(questionIdsValue);
            int i = 0;
            while (matcher.find()) {
                ++i;
                if (i > 0 && i % 2 == 0) {
                    questionsIds.add(Long.parseLong(matcher.group(1)));
                }
            }
            return questionsIds;
        }
        return Collections.emptyList();
    }

    @Transactional(rollbackFor = Exception.class)
    public SubmitAnswerResponse submitAnswer(String email,
                                             @NotNull Long quizId,
                                             @NotNull SubmitAnswerRequest request) throws AppException {
        final User user = userRepository
                .findByEmail(email)
                .orElseThrow(() -> new AppException(ErrorCode.QUIZ_NOT_FOUND));

        final QuizDto quizDto = quizMasterRepository
                .findActiveQuizById(quizId, List.of(PostStatus.PUBLISH, PostStatus.PRIVATE))
                .orElseThrow(() -> new AppException(ErrorCode.QUIZ_NOT_FOUND));

        List<QuestionEntity> questionEntities = Collections.emptyList();
        final List<Long> questionsIds = getQuestionIds(quizDto.getPostId());
        if (!CollectionUtils.isEmpty(questionsIds)) {
            questionEntities = questionRepository.findAllByIdIn(questionsIds);
        }

        final Set<Long> questionIds = request.getData()
                .stream()
                .map(AnsweredData::getQuestionId)
                .collect(Collectors.toSet());
        final List<QuestionResponse> questionResponses =
                questionEntities.stream()
                        .filter(x -> questionIds.contains(x.getId()))
                        .map(QuestionResponse::from)
                        .toList();

        final PostMeta postMeta = postMetaRepository.findByPostIdAndMetaKey(quizDto.getPostId(), "_sfwd-quiz");
        final String quizMeta = postMeta.getMetaValue();
        int passPercentage = 0;
        if (Objects.nonNull(quizMeta)) {
            final Map<String, Object> quizMetaMap = PostMetaUtil.getPostMetaValues(quizMeta);
            final Object passingPercentage = quizMetaMap.get("sfwd-quiz_passingpercentage");

            if (Objects.nonNull(passingPercentage)) {
                passPercentage = Integer.parseInt(passingPercentage.toString());
            }
        }

        final QuizStatisticRefEntity quizStatisticRefEntity = new QuizStatisticRefEntity();
        quizStatisticRefEntity.setQuizId(quizId);
        quizStatisticRefEntity.setQuizPostId(quizDto.getPostId());
        quizStatisticRefEntity.setCoursePostId(0L);
        quizStatisticRefEntity.setUserId(user.getId());
        quizStatisticRefEntity.setCreateTime(Instant.now().getEpochSecond());
        quizStatisticRefEntity.setIsOld(0);
        quizStatisticRefEntity.setFormData(null);
        quizStatisticRefRepository.save(quizStatisticRefEntity);

        final Map<Long, AnsweredData> answeredDataMap = request.getData()
                .stream()
                .collect(toMap(AnsweredData::getQuestionId,
                        Function.identity()));
        final Long answeredCount = request.getData().stream()
                .filter(x -> x.getAnswerData() != null
                        && x.getAnswerData().contains(Boolean.TRUE))
                .count();
        final List<QuizStatisticEntity> quizStatisticEntities =
                questionResponses.stream()
                        .map(x -> createQuizStatistic(x, answeredDataMap.get(x.getId()),
                                quizStatisticRefEntity.getId()))
                        .toList();
        quizStatisticRepository.saveAll(quizStatisticEntities);

        final UserActivityEntity userActivityEntity = new UserActivityEntity();
        userActivityEntity.setUserId(user.getId());
        userActivityEntity.setActivityStarted(request.getStartTime());
        userActivityEntity.setActivityCompleted(request.getEndTime());
        userActivityEntity.setActivityUpdated(request.getEndTime());
        userActivityEntity.setActivityType("quiz");
        userActivityEntity.setActivityStatus(0);
        userActivityEntity.setCourseId(0L);
        userActivityEntity.setPostId(quizDto.getPostId());
        userActivityRepository.save(userActivityEntity);

        final Long activityId = userActivityEntity.getId();
        final List<UserActivityMetaEntity> activityMetaEntities = new ArrayList<>();
        activityMetaEntities.add(createActivityMeta(activityId, "quiz", quizDto.getPostId().toString()));

        final Long points = quizStatisticEntities.stream()
                .filter(Objects::nonNull)
                .mapToLong(QuizStatisticEntity::getPoints)
                .sum();
        final Long corrects = quizStatisticEntities.stream()
                .filter(Objects::nonNull)
                .mapToLong(QuizStatisticEntity::getCorrectCount)
                .sum();
        final Long inCorrects = quizStatisticEntities.stream()
                .filter(Objects::nonNull)
                .mapToLong(QuizStatisticEntity::getIncorrectCount)
                .sum();
        final Long totalPoints = questionEntities.stream()
                .filter(Objects::nonNull)
                .mapToLong(QuestionEntity::getPoints)
                .sum();
        final BigDecimal percentage = new BigDecimal(points * 100.0 / totalPoints)
                .setScale(2, RoundingMode.HALF_EVEN);
        final boolean pass = percentage.compareTo(new BigDecimal(passPercentage)) >= 0;
        activityMetaEntities.add(createActivityMeta(activityId, "score", String.valueOf(points)));
        activityMetaEntities.add(createActivityMeta(activityId, "points", String.valueOf(points)));
        activityMetaEntities.add(createActivityMeta(activityId, "corrects", String.valueOf(corrects)));
        activityMetaEntities.add(createActivityMeta(activityId, "inCorrects", String.valueOf(inCorrects)));
        activityMetaEntities.add(createActivityMeta(activityId, "percentage", percentage.toString()));
        activityMetaEntities.add(createActivityMeta(activityId, "pass", pass ? "1" : "0"));
        activityMetaEntities.add(
                createActivityMeta(activityId, "answeredCount", String.valueOf(answeredCount)));

        activityMetaEntities.add(createActivityMeta(activityId, "total_points", String.valueOf(totalPoints)));
        activityMetaEntities.add(
                createActivityMeta(activityId, "count", String.valueOf(questionEntities.size())));
        activityMetaEntities.add(
                createActivityMeta(activityId, "question_show_count", String.valueOf(questionEntities.size())));

        activityMetaEntities.add(
                createActivityMeta(activityId, "time", String.valueOf(request.getEndTime())));
        activityMetaEntities.add(
                createActivityMeta(activityId, "started", String.valueOf(request.getStartTime())));
        activityMetaEntities.add(
                createActivityMeta(activityId, "completed", String.valueOf(request.getEndTime())));
        activityMetaEntities.add(
                createActivityMeta(activityId, "timespent",
                        String.valueOf(request.getEndTime() - request.getStartTime())));

        activityMetaEntities.add(
                createActivityMeta(activityId, "pro_quizid", String.valueOf(quizId)));
        activityMetaEntities.add(
                createActivityMeta(activityId, "course", "0"));
        activityMetaEntities.add(
                createActivityMeta(activityId, "lesson", "0"));
        activityMetaEntities.add(
                createActivityMeta(activityId, "topic", "0"));
        activityMetaEntities.add(
                createActivityMeta(activityId, "has_graded", ""));
        activityMetaEntities.add(
                createActivityMeta(activityId, "statistic_ref_id",
                        String.valueOf(quizStatisticRefEntity.getId())));
        userActivityMetaRepository.saveAll(activityMetaEntities);

        return SubmitAnswerResponse.builder()
                .point(points)
                .totalPoint(totalPoints)
                .percentage(percentage.doubleValue())
                .passPercentage(passPercentage)
                .pass(pass)
                .corrects(corrects)
                .inCorrects(inCorrects)
                .questions((long) questionEntities.size())
                .answeredQuestions(answeredCount)
                .answeredTime(request.getEndTime() - request.getStartTime())
                .build();
    }

    private static UserActivityMetaEntity createActivityMeta(final Long activityId,
                                                             final String key,
                                                             final String value) {
        final UserActivityMetaEntity entity = new UserActivityMetaEntity();
        entity.setActivityId(activityId);
        entity.setActivityMetaKey(key);
        entity.setActivityMetaValue(value);

        return entity;
    }

    private static QuizStatisticEntity createQuizStatistic(final @NotNull QuestionResponse question,
                                                           final AnsweredData answeredData,
                                                           final Long refId) {
        final QuizStatisticId id = new QuizStatisticId();
        id.setQuestionId(question.getId());
        id.setStatisticRefId(refId);

        final List<Integer> selectedList =
                (Objects.isNull(answeredData)
                        || Objects.isNull(answeredData.getAnswerData())) ? List.of()
                        : answeredData.getAnswerData()
                        .stream()
                        .map(QuizMasterService::booleanToInt)
                        .toList();
        final List<Integer> correctList =
                (Objects.isNull(question.getAnswerData())) ? List.of()
                        : question.getAnswerData()
                        .stream()
                        .sorted(Comparator.comparing(
                                AnswerData::getIndex))
                        .map(x -> booleanToInt(x.isCorrect()))
                        .toList();

        final boolean correct = selectedList.toString().equals(correctList.toString());
        System.out.println("--------" + question.getId() + "-----------");
        System.out.println(selectedList);
        System.out.println(correctList);

        final QuizStatisticEntity entity = new QuizStatisticEntity();
        entity.setId(id);
        entity.setPoints(correct ? Objects.requireNonNullElse(question.getPoints(), 0).longValue() : 0L);
        entity.setAnswerData(selectedList.toString());
        entity.setHintCount(0L);
        entity.setCorrectCount(correct ? 1L : 0L);
        entity.setIncorrectCount(!correct ? 1L : 0L);
        entity.setQuestionPostId(0L);
        entity.setQuestionTime(0L);

        return entity;
    }

    private static int booleanToInt(final Boolean value) {
        return Boolean.TRUE.equals(value) ? 1 : 0;
    }

    public static void main(String[] args) {
        final LocalDateTime currTime = LocalDateTime.now();
        System.out.println(currTime);

        final String str = "2024-01-09 21:59:59";
        final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        final LocalDateTime dateTime = LocalDateTime.parse(str, formatter);

        System.out.println(DAYS.between(currTime, dateTime));
    }
}
