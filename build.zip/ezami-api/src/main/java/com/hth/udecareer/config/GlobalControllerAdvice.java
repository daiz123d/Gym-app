package com.hth.udecareer.config;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

import com.hth.udecareer.enums.ErrorCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import javax.validation.ConstraintViolationException;
import javax.validation.ConstraintViolation;
import java.util.stream.Collectors;

import org.slf4j.MarkerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import com.hth.udecareer.exception.AppException;
import com.hth.udecareer.model.response.ApiResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestControllerAdvice
public class GlobalControllerAdvice implements ResponseBodyAdvice<Object> {

    @ExceptionHandler(AppException.class)
    public ApiResponse catchAppException(HttpServletRequest request,
            HttpServletResponse response,
            AppException e) {
        ErrorCode errorCode = e.getErrorCode();
        HttpStatus httpStatus = errorCode.getHttpStatus();


        response.setStatus(httpStatus.value());


        log.warn(
                MarkerFactory.getMarker("APP_EXCEPTION"),
                "AppException: URI[{}], Query[{}], Method[{}], ErrorCode[{}], HttpStatus[{}], Message[{}]",
                request.getRequestURI(),
                request.getQueryString(),
                request.getMethod(),
                errorCode.name(),
                httpStatus.value(),
                errorCode.getMessage(),
                e);

        return ApiResponse.builder()
                .code(errorCode.getCode())
                .message(errorCode.getMessage())
                .build();
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<ApiResponse> handleValidationExceptions(MethodArgumentNotValidException ex) {

        org.springframework.validation.FieldError fieldError = ex.getBindingResult().getFieldError();
        String errorKey = fieldError != null ? fieldError.getDefaultMessage() : null;

        ErrorCode errorCode = ErrorCode.INVALID_KEY; // set default neu k duoc define truoc
        Map<String, Object> attributes = null; // cac thuoc tinh vi pham

        try {
            if (errorKey != null) {

                if ("USERNAME_REQUIRED".equals(errorKey) || "PASSWORD_REQUIRED".equals(errorKey)) {
                    errorCode = ErrorCode.INVALID_CREDENTIALS;
                } else {

                    errorCode = ErrorCode.valueOf(errorKey);
                }


                if (!ex.getBindingResult().getAllErrors().isEmpty()) {
                    try {
                        ConstraintViolation constraintViolation = ex.getBindingResult().getAllErrors().get(0)
                                .unwrap(ConstraintViolation.class);
                        attributes = constraintViolation.getConstraintDescriptor().getAttributes();
                    } catch (Exception e) {

                    }
                }
            }
        } catch (IllegalArgumentException e) {

            log.debug("ErrorCode not found for validation error key: {}", errorKey);
        }

        ApiResponse apiResponse = new ApiResponse();
        apiResponse.setCode(errorCode.getCode());


        String finalMessage = errorCode.getMessage();
        if (Objects.nonNull(attributes)) {
            finalMessage = mapAttribute(errorCode.getMessage(), attributes);
        }
        apiResponse.setMessage(finalMessage);


        return ResponseEntity.status(errorCode.getHttpStatus()).body(apiResponse);
    }

    private static final String MIN_ATTRIBUTE = "min";

    private String mapAttribute(String message, Map<String, Object> attributes) {
        String minValue = String.valueOf(attributes.get(MIN_ATTRIBUTE));

        return message.replace("{" + MIN_ATTRIBUTE + "}", minValue);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ApiResponse handleConstraintViolationException(ConstraintViolationException ex) {
        String errorMessage = ex.getConstraintViolations()
                .stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.joining(", "));
        return ApiResponse.fail(HttpStatus.BAD_REQUEST, "Validation failed: " + errorMessage);
    }

    @ExceptionHandler(Exception.class)
    public ApiResponse catchAnyException(HttpServletRequest request,
            HttpServletResponse response,
            Exception e) {
        final Pair<Integer, String> status = handleAnyException(request, e);
        response.setStatus(status.getFirst());
        return ApiResponse.fail(status.getFirst(), status.getSecond());
    }

    public static Pair<Integer, String> handleAnyException(HttpServletRequest request, Exception e) {
        return handleAnyException(request, e, null);
    }

    public static Pair<Integer, String> handleAnyException(@NotNull HttpServletRequest request,
            @NotNull Exception e,
            @Null Set<String> sensitiveHeaderNames) {
        try {
            final ResponseStatus responseStatus = AnnotationUtils.findAnnotation(e.getClass(), ResponseStatus.class);
            final HttpStatus status = responseStatus == null ? HttpStatus.INTERNAL_SERVER_ERROR
                    : responseStatus.value();
            final String message = (status.value() < HttpStatus.INTERNAL_SERVER_ERROR.value())
                    ? e.getMessage()
                    : HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase();

            if (status.value() < HttpStatus.INTERNAL_SERVER_ERROR.value()) {
                log.warn(
                        MarkerFactory.getMarker("EXCEPTION_ORIGINAL_LOCATION"),
                        "Error: URI[{}], Query[{}], Method[{}], Code[{}], Headers[{}], Message[{}]",
                        request.getRequestURI(),
                        request.getQueryString(),
                        request.getMethod(),
                        status.value(),
                        generateHeadersString(request, sensitiveHeaderNames),
                        message,
                        e);
            } else {
                log.error(
                        MarkerFactory.getMarker("EXCEPTION_ORIGINAL_LOCATION"),
                        "Unexpected Error: URI[{}], Query[{}], Method[{}], Code[{}], Headers[{}], Message[{}]",
                        request.getRequestURI(),
                        request.getQueryString(),
                        request.getMethod(),
                        status.value(),
                        generateHeadersString(request, sensitiveHeaderNames),
                        e.getMessage(),
                        e);
            }
            return Pair.of(status.value(), message);
        } catch (Exception ex) {
            log.error(ex.getMessage(), e);
            throw ex;
        }
    }

    protected static String generateHeadersString(HttpServletRequest request, Set<String> sensitiveHeaderNames) {
        final StringBuilder rsl = new StringBuilder();
        final Enumeration<String> headers = request.getHeaderNames();
        while (headers.hasMoreElements()) {
            final String name = headers.nextElement();
            final String val = request.getHeader(name);
            if (val == null) {
                continue;
            }
            rsl.append(name).append(": ");
            final char[] valChars = val.toCharArray();
            if (sensitiveHeaderNames != null && sensitiveHeaderNames.contains(name)) {
                Arrays.fill(valChars, 0, valChars.length, '*');
            }
            rsl.append(valChars);
            if (headers.hasMoreElements()) {
                rsl.append('|');
            }
        }
        return rsl.toString();
    }

    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType,
            Class<? extends HttpMessageConverter<?>> selectedConverterType,
            ServerHttpRequest request, ServerHttpResponse response) {


        String requestPath = request.getURI().getPath();
        if (requestPath.contains("/v3/api-docs") ||
                requestPath.contains("/swagger-ui") ||
                requestPath.contains("/swagger-resources") ||
                requestPath.contains("/webjars") ){
            return body;
        }

        if (body instanceof ApiResponse) {
            return body;
        }
        return ApiResponse.success(body);
    }
}
