package com.hth.udecareer.controllers;

import java.util.List;
import java.util.Optional;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hth.udecareer.annotation.ApiPrefixController;
import com.hth.udecareer.model.response.ArticleSpaceResponse;
import com.hth.udecareer.model.response.PostResponse;
import com.hth.udecareer.service.PostService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@ApiPrefixController
@RequiredArgsConstructor
@Tag(name = "Post (Article) Public API")
public class PostController {
    private final PostService postService;


    @Operation(
            summary = "Tìm kiếm bài viết theo danh mục", 
            description = """
                    **Tìm kiếm danh sách bài viết (articles), có thể lọc theo danh mục**
                    
                    API công khai này trả về danh sách các bài viết/tin tức trong hệ thống.
                    
                    **Tham số:**
                    - **categoryId** (tùy chọn): ID của danh mục cần lọc
                    - Không truyền categoryId = lấy tất cả bài viết
                    
                    **Response:**
                    - Danh sách bài viết với thông tin cơ bản (không bao gồm nội dung đầy đủ)
                    - Chỉ trả về các bài đã publish (status = PUBLISH)
                    
                    **Use cases:**
                    - Hiển thị danh sách bài viết trên blog/news
                    - Lọc bài viết theo chủ đề/danh mục
                    - Danh sách preview cho người dùng chưa đăng nhập
                    
                    **Lưu ý:**
                    - API này KHÔNG yêu cầu authentication (public)
                    - Content chỉ là excerpt/summary, không phải full content
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Tìm thấy danh sách bài viết"),
            @ApiResponse(responseCode = "500", description = "Lỗi server", content = @Content),
            @ApiResponse(responseCode = "default",
                    description = "Lỗi không mong đợi",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
    })
    @GetMapping("/post")
    public List<PostResponse> searchPost(
            @io.swagger.v3.oas.annotations.Parameter(
                    description = "ID của danh mục cần lọc (tùy chọn). Không truyền = lấy tất cả bài viết",
                    example = "5",
                    required = false
            )
            @RequestParam(value = "categoryId", required = false) Long categoryId) {
        log.info("searchPost: categoryId {}", categoryId);
        return postService.findAllByCategory(categoryId);
    }

    @Operation(
            summary = "Lấy danh sách Article Spaces", 
            description = """
                    **Lấy danh sách các Article Spaces (không gian bài viết)**
                    
                    Article Space là một tập hợp các bài viết được nhóm lại theo một chủ đề/topic cụ thể.
                    
                    **Tham số:**
                    - **language** (tùy chọn): Mã ngôn ngữ (vd: "vn", "en"), mặc định "vn"
                    - **appCode** (tùy chọn): Mã ứng dụng, mặc định "ezami"
                    - **withCategory** (tùy chọn): Include categories hay không, mặc định true
                    
                    **Response:**
                    - Danh sách article spaces với metadata
                    - Categories trong space (nếu withCategory = true)
                    - Số lượng bài viết trong mỗi space/category
                    
                    **Use cases:**
                    - Hiển thị danh sách chủ đề bài viết
                    - Navigation/menu cho blog section
                    - Multi-language content organization
                    
                    **Lưu ý:**
                    - API này KHÔNG yêu cầu authentication (public)
                    - Hỗ trợ đa ngôn ngữ và multi-app
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lấy danh sách article spaces thành công"),
            @ApiResponse(responseCode = "500", description = "Lỗi server", content = @Content),
            @ApiResponse(responseCode = "default",
                    description = "Lỗi không mong đợi",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
    })
    @GetMapping("/post/space")
    public List<ArticleSpaceResponse> searchPostSpace(
            @io.swagger.v3.oas.annotations.Parameter(
                    description = "Mã ngôn ngữ (vd: 'vn', 'en')",
                    example = "vn",
                    required = false
            )
            @RequestParam(value = "language", required = false) String language,
            @io.swagger.v3.oas.annotations.Parameter(
                    description = "Mã ứng dụng",
                    example = "ezami",
                    required = false
            )
            @RequestParam(value = "appCode", required = false) String appCode,
            @io.swagger.v3.oas.annotations.Parameter(
                    description = "Có bao gồm categories trong response hay không",
                    example = "true",
                    required = false
            )
            @RequestParam(value = "withCategory", required = false) Boolean withCategory) {
        log.info("searchPostSpace: appCode {}, language {}", appCode, language);
        return postService.findAllSpace(Optional.ofNullable(appCode).orElse("ezami"),
                Optional.ofNullable(language).orElse("vn"),
                Optional.ofNullable(withCategory).orElse(true));
    }

    @Operation(
            summary = "Lấy chi tiết một Article Space", 
            description = """
                    **Lấy thông tin chi tiết của một Article Space cụ thể**
                    
                    API này trả về thông tin đầy đủ của một article space theo ID.
                    
                    **Tham số:**
                    - **spaceId** (bắt buộc): ID của article space cần lấy
                    - **language** (tùy chọn): Mã ngôn ngữ, mặc định "vn"
                    
                    **Response:**
                    - Thông tin chi tiết article space
                    - Danh sách categories trong space
                    - Metadata và cấu hình
                    
                    **Use cases:**
                    - Hiển thị chi tiết một chủ đề bài viết
                    - Load categories để filter bài viết
                    - Navigation breadcrumb
                    
                    **Lưu ý:**
                    - API này KHÔNG yêu cầu authentication (public)
                    - Throw 404 nếu không tìm thấy space
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Tìm thấy article space"),
            @ApiResponse(responseCode = "404", description = "Không tìm thấy article space", content = @Content),
            @ApiResponse(responseCode = "500", description = "Lỗi server", content = @Content),
            @ApiResponse(responseCode = "default",
                    description = "Lỗi không mong đợi",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
    })
    @GetMapping("/post/space/{spaceId}")
    public ArticleSpaceResponse getPostSpace(
            @io.swagger.v3.oas.annotations.Parameter(
                    description = "ID của article space cần lấy",
                    required = true,
                    example = "10"
            )
            @PathVariable("spaceId") Long spaceId,
            @io.swagger.v3.oas.annotations.Parameter(
                    description = "Mã ngôn ngữ (vd: 'vn', 'en')",
                    example = "vn",
                    required = false
            )
            @RequestParam(value = "language", required = false) String language) throws Exception {
        log.info("getPostSpace: spaceId {}, language {}", spaceId, language);
        return postService.getSpace(spaceId, Optional.ofNullable(language).orElse("vn"));
    }

    @Operation(
            summary = "Lấy chi tiết bài viết", 
            description = """
                    **Lấy thông tin đầy đủ của một bài viết cụ thể**
                    
                    API này trả về toàn bộ nội dung của một bài viết theo ID.
                    
                    **Tham số:**
                    - **postId** (bắt buộc): ID của bài viết cần lấy
                    
                    **Response:**
                    - ID, title, name (slug)
                    - **Full content** (HTML) của bài viết
                    - Status (PUBLISH, DRAFT, PRIVATE)
                    - Type (post, page, etc.)
                    
                    **Use cases:**
                    - Hiển thị trang đọc bài viết đầy đủ
                    - Preview bài viết trong editor
                    - Share link bài viết cụ thể
                    
                    **Lưu ý:**
                    - API này KHÔNG yêu cầu authentication (public)
                    - Chỉ trả về bài có status = PUBLISH
                    - Content là HTML, cần render đúng cách ở client
                    - Throw 404 nếu không tìm thấy bài viết
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Tìm thấy bài viết"),
            @ApiResponse(responseCode = "404", description = "Không tìm thấy bài viết", content = @Content),
            @ApiResponse(responseCode = "500", description = "Lỗi server", content = @Content),
            @ApiResponse(responseCode = "default",
                    description = "Lỗi không mong đợi",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
    })
    @GetMapping("/post/{postId}")
    public PostResponse getPostInfo(
            @io.swagger.v3.oas.annotations.Parameter(
                    description = "ID của bài viết cần lấy",
                    required = true,
                    example = "42"
            )
            @PathVariable("postId") Long postId) throws Exception {
        log.info("getPostInfo: postId {}", postId);
        return postService.findById(postId);
    }
}