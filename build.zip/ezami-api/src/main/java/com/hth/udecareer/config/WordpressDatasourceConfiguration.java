package com.hth.udecareer.config;

import net.ttddyy.dsproxy.support.ProxyDataSourceBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.Objects;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = {"com.hth.udecareer.entities", "com.hth.udecareer.repository"},
        entityManagerFactoryRef = "wordpressEntityManagerFactory",
        transactionManagerRef = "wordpressTransactionManager"
)
public class WordpressDatasourceConfiguration {
    @Bean
    @Primary
    @ConfigurationProperties("spring.datasource.wordpress")
    public DataSourceProperties wordpressDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean
    @Primary
    public DataSource wordpressDataSource() {
        DataSource realDataSource = wordpressDataSourceProperties()
                .initializeDataSourceBuilder()
                .build();

//        return ProxyDataSourceBuilder
//                .create(realDataSource)
//                .name("WordpressDS")
//                .logQueryBySlf4j() // log qua logger
//                .countQuery()
//                .multiline() // dễ đọc
//                .build();

        return wordpressDataSourceProperties()
                .initializeDataSourceBuilder()
                .build();
    }

    @Bean
    @Primary
    public JdbcTemplate wordpressJdbcTemplate(@Qualifier("wordpressDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean
    @Primary
    public LocalContainerEntityManagerFactoryBean wordpressEntityManagerFactory(
            @Qualifier("wordpressDataSource") DataSource dataSource,
            EntityManagerFactoryBuilder builder) {
        return builder
                .dataSource(dataSource)
                .packages("com.hth.udecareer.entities")
                .build();
    }

    @Bean
    @Primary
    public PlatformTransactionManager wordpressTransactionManager(
            @Qualifier("wordpressEntityManagerFactory") LocalContainerEntityManagerFactoryBean wordpressEntityManagerFactory) {
        return new JpaTransactionManager(Objects.requireNonNull(wordpressEntityManagerFactory.getObject()));
    }
}
