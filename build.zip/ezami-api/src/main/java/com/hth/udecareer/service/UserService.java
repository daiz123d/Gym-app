package com.hth.udecareer.service;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.annotation.Nullable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.hth.udecareer.enums.ErrorCode;
import com.hth.udecareer.model.request.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.hth.udecareer.entities.User;
import com.hth.udecareer.enums.VerificationCodeType;
import com.hth.udecareer.exception.AppException;
import com.hth.udecareer.model.response.UserResponse;
import com.hth.udecareer.repository.UserRepository;
import com.hth.udecareer.security.PhpPasswordEncoder;
import com.hth.udecareer.model.dto.google.GoogleUserInfo;
import java.util.UUID;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserService {
    private static final String APP_CODE_DEFAULT = "ezami";

    private final UserRepository userRepository;
    private final PhpPasswordEncoder passwordEncoder;
    private final VerificationCodeService verificationCodeService;

    public UserResponse findByEmail(String email) throws AppException {
        final User user = userRepository
                .findByEmail(email)
                .orElseThrow(() -> new AppException(ErrorCode.EMAIL_USER_NOT_FOUND));

        return UserResponse.from(user);
    }

    public UserResponse signup(@NotNull RegisterWithCodeRequest request) throws Exception {
        final String appCode = StringUtils.isNotBlank(request.getAppCode()) ? request.getAppCode() : APP_CODE_DEFAULT;
        return signup(appCode,
                request.getEmail(),
                request.getPassword(),
                request.getVerificationCode(),
                true,
                request.getFullName());
    }

    public UserResponse signup(@NotNull RegisterRequest request) throws Exception {
        final String appCode = StringUtils.isNotBlank(request.getAppCode()) ? request.getAppCode() : APP_CODE_DEFAULT;
        return signup(appCode,
                request.getEmail(),
                request.getPassword(),
                null,
                false,
                request.getFullName());
    }

    private UserResponse signup(@NotNull String appCode,
            @NotBlank String email,
            @NotBlank String password,
            @Nullable String code,
            boolean verifyCode,
            @NotBlank String fullName) throws AppException {
        if (verifyCode) {
            if (Objects.isNull(code)) {
                log.error("Verification code for user {} is null", email);
                throw new AppException(ErrorCode.INVALID_CODE);
            }
            try {
                verificationCodeService.checkVerificationCode(email, code, VerificationCodeType.REGISTER);

            } catch (Exception ex) {
                log.error(ex.getMessage() + ", email: {}, code: {}", email, code);
                throw ex;
            }
        }

        final Optional<User> userOpt = userRepository.findByEmail(email);
        if (userOpt.isPresent()) {
            log.error("The email {} is already associated with an account.", email);
            throw new AppException(ErrorCode.EMAIL_INFO_EXISTED);
        }

        final String usernameFromEmail = getUsernameFromEmail(email);
        final Set<String> existedUsernames = userRepository.findByUsernameStartingWith(usernameFromEmail)
                .stream()
                .map(User::getUsername)
                .collect(Collectors.toSet());
        String username = null;
        int i = 1;
        do {
            final String tempUsername = usernameFromEmail + '_' + i;
            if (!existedUsernames.contains(tempUsername)) {
                username = tempUsername;
            }
            ++i;
        } while (Objects.isNull(username));

        final User user = new User();
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(password.trim()));
        user.setUsername(username);
        user.setNiceName(username);
        user.setDisplayName(StringUtils.isNotBlank(fullName) ? fullName.trim() : username);
        user.setStatus(0);
        user.setActivationKey("");
        user.setUserUrl("");
        user.setRegisteredDate(LocalDateTime.now());
        user.setAppCode(appCode);

        final User savedUser = userRepository.save(user);
        verificationCodeService.deleteVerificationCodeAfterUse(email, code, VerificationCodeType.REGISTER);
        return UserResponse.from(savedUser);
    }

    public void updateUserInfo(@NotNull UpdateUserInfoRequest request,
            @NotNull String oldEmail) throws AppException {
        final User user = userRepository
                .findByEmail(oldEmail)
                .orElseThrow(() -> new AppException(ErrorCode.EMAIL_USER_NOT_FOUND));


        final String preferredName = StringUtils.isNotBlank(request.getDisplayName())
                ? request.getDisplayName()
                : request.getFullName();

        if (StringUtils.isNotBlank(preferredName)) {
            user.setDisplayName(preferredName.trim());
        }

        if (StringUtils.isNotBlank(request.getNiceName())) {
            user.setNiceName(request.getNiceName().trim());
        }

        if (StringUtils.isNotBlank(request.getUserUrl())) {
            user.setUserUrl(request.getUserUrl().trim());
        }


        userRepository.save(user);
    }

    public void changePass(@NotNull ChangePassRequest request,
            @NotNull String email) throws AppException {
        final User user = userRepository
                .findByEmail(email)
                .orElseThrow(() -> new AppException(ErrorCode.EMAIL_USER_NOT_FOUND));

        if (!passwordEncoder.matches(request.getOldPass(), user.getPassword())) {
            throw new AppException(ErrorCode.OLD_PASSWORD_INCORRECT);
        }

        user.setPassword(passwordEncoder.encode(request.getNewPass()));
        userRepository.save(user);
    }

    public void resetPass(@NotNull ResetPasswordRequest request) throws AppException {
        final User user = userRepository
                .findByEmail(request.getEmail())
                .orElseThrow(() -> new AppException(ErrorCode.EMAIL_USER_NOT_FOUND));

        verificationCodeService.checkVerificationCode(request.getEmail(), request.getVerificationCode(),
                VerificationCodeType.RESET_PASS);

        user.setPassword(passwordEncoder.encode(request.getPassword()));
        userRepository.save(user);

        verificationCodeService.deleteVerificationCodeAfterUse(request.getEmail(), request.getVerificationCode(),
                VerificationCodeType.RESET_PASS);
    }

    @Transactional
    public void deleteAccount(@NotNull String email, @Nullable DeleteAccountRequest request) throws AppException {
        if (request != null
                && StringUtils.isNotBlank(request.getConfirmationText())
                && !"DELETE".equals(request.getConfirmationText())) {
            throw new AppException(ErrorCode.INVALID_CONFIRMATION_TEXT);
        }
        final User user = userRepository
                .findByEmail(email)
                .orElseThrow(() -> new AppException(ErrorCode.EMAIL_USER_NOT_FOUND));

        userRepository.delete(user);
    }

    public void generateVerificationCode(@NotNull String email,
            @NotNull VerificationCodeType type) throws Exception {
        final Optional<User> userOpt = userRepository.findByEmail(email);

        if (type == VerificationCodeType.RESET_PASS) {

            if (userOpt.isEmpty()) {
                throw new AppException(ErrorCode.EMAIL_NOT_FOUND);
            }
            verificationCodeService.createVerificationCode(userOpt.get().getId(), email, type, true);

        } else if (type == VerificationCodeType.REGISTER) {

            if (userOpt.isPresent()) {
                throw new AppException(ErrorCode.EMAIL_INFO_EXISTED);
            }
            verificationCodeService.createVerificationCode(null, email, type, true);
        }
    }

    private static String getUsernameFromEmail(@NotNull final String email) {
        return Pattern.compile("([a-zA-Z]+)[^a-zA-Z@]*(@.*)?")
                .matcher(email).results()
                .map(result -> result.group(1))
                .collect(Collectors.joining(""));
    }

    public User findOrCreateGoogleUser(GoogleUserInfo userInfo) throws AppException {
        final String email = userInfo.getEmail();
        if (StringUtils.isBlank(email)) {
            throw new AppException(ErrorCode.GOOGLE_AUTH_EMAIL_MISSING);
        }


        final Optional<User> userOpt = userRepository.findByEmail(email);

        if (userOpt.isPresent()) {

            log.info("Google Login: User {} đã tồn tại.", email);
            User existingUser = userOpt.get();

            return userRepository.save(existingUser);
        }


        log.info("Google Register: User {} chưa tồn tại. Đang tạo user mới.", email);

        final String usernameFromEmail = getUsernameFromEmail(email);
        final Set<String> existedUsernames = userRepository.findByUsernameStartingWith(usernameFromEmail)
                .stream()
                .map(User::getUsername)
                .collect(Collectors.toSet());
        String username = null;
        int i = 1;
        do {
            final String tempUsername = usernameFromEmail + '_' + i;
            if (!existedUsernames.contains(tempUsername)) {
                username = tempUsername;
            }
            ++i;
        } while (Objects.isNull(username));


        final User user = new User();
        user.setEmail(email);

        String randomPassword = UUID.randomUUID().toString();
        user.setPassword(passwordEncoder.encode(randomPassword));

        user.setUsername(username);
        user.setNiceName(username);
        user.setDisplayName(userInfo.getName());
        user.setStatus(0);
        user.setActivationKey("");
        user.setUserUrl("");
        user.setRegisteredDate(LocalDateTime.now());
        user.setAppCode(APP_CODE_DEFAULT);

        final User savedUser = userRepository.save(user);

        log.info("User registered successfully via Google: {}", email);

        return savedUser;
    }
}
