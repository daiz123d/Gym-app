package com.hth.udecareer.repository;

import com.hth.udecareer.entities.UserPurchasedEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserPurchasedRepository extends JpaRepository<UserPurchasedEntity, Long> {

    List<UserPurchasedEntity> findAllByUserIdOrUserEmail(Long userId, String userEmail);
}
