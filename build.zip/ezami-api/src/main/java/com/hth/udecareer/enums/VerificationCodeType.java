package com.hth.udecareer.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum VerificationCodeType {
    RESET_PASS,
    REGISTER
}
