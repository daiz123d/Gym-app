package com.hth.udecareer.entities;

import lombok.Data;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "wp_term_relationships")
public class TermRelationshipEntity {
    @EmbeddedId
    private TermRelationshipId id;

    private Long term_order;
}
