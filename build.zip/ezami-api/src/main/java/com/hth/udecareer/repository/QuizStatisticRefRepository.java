package com.hth.udecareer.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hth.udecareer.entities.QuizStatisticRefEntity;

public interface QuizStatisticRefRepository extends JpaRepository<QuizStatisticRefEntity, Long> {
}
