package com.hth.udecareer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hth.udecareer.entities.UserActivityEntity;

@Repository
public interface UserActivityRepository extends JpaRepository<UserActivityEntity, Long> {

    @Query("SELECT uae FROM UserActivityEntity uae "
           + "WHERE uae.id IN "
           + "(SELECT MAX(uay.id) "
           + "FROM UserActivityEntity uay "
           + "WHERE uay.userId = :userId AND uay.activityType = 'quiz' "
           + "GROUP BY uay.postId)")
    List<UserActivityEntity> getLatestActivityByUserId(@Param("userId") Long userId);
}
