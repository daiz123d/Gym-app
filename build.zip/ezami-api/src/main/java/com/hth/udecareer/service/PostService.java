package com.hth.udecareer.service;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.hth.udecareer.entities.ArticleSpaceCategoryEntity;
import com.hth.udecareer.entities.ArticleSpaceEntity;
import com.hth.udecareer.entities.Post;
import com.hth.udecareer.entities.TermEntity;
import com.hth.udecareer.enums.ErrorCode;
import com.hth.udecareer.enums.PostStatus;
import com.hth.udecareer.exception.AppException;
import com.hth.udecareer.model.response.ArticleSpaceResponse;
import com.hth.udecareer.model.response.PostResponse;
import com.hth.udecareer.repository.ArticleSpaceCategoryRepository;
import com.hth.udecareer.repository.ArticleSpaceRepository;
import com.hth.udecareer.repository.PostRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class PostService {
    private final PostRepository postRepository;
    private final ArticleSpaceRepository articleSpaceRepository;
    private final ArticleSpaceCategoryRepository articleSpaceCategoryRepository;

    @Cacheable(value = "article_spaces", key = "#appCode + ':' + #language + ':' + #withCategory")
    public List<ArticleSpaceResponse> findAllSpace(@NotNull String appCode,
                                                   @NotNull String language,
                                                   boolean withCategory) {
        final List<ArticleSpaceEntity> articleSpaceEntityList = articleSpaceRepository.findAllEnableByAppCode(appCode);

        final List<ArticleSpaceResponse> articleSpaceResponses;
        if (withCategory) {
            final List<ArticleSpaceCategoryEntity> articleSpaceCategoryEntities =
                    articleSpaceCategoryRepository.findAllEnableByLanguage(language);
            final Multimap<Long, ArticleSpaceCategoryEntity> spaceToCategory = ArrayListMultimap.create();
            articleSpaceCategoryEntities.forEach(x -> spaceToCategory.put(x.getSpace_id(), x));

            final Map<String, TermEntity> categoryMap = getCategoryMap(articleSpaceCategoryEntities);

            articleSpaceResponses = articleSpaceEntityList
                    .stream()
                    .map(space -> {
                        final Collection<ArticleSpaceCategoryEntity> categoryEntities = spaceToCategory.get(
                                space.getId());

                        return getSpaceResponse(space, categoryEntities, categoryMap);
                    })
                    .filter(x -> !CollectionUtils.isEmpty(x.getCategories()))
                    .collect(Collectors.toList());
        } else {
            articleSpaceResponses = articleSpaceEntityList
                    .stream()
                    .map(space -> ArticleSpaceResponse.from(space.getId(), space.getTitle()))
                    .collect(Collectors.toList());
        }

        return articleSpaceResponses;
    }

    private Map<String, TermEntity> getCategoryMap(
            final List<ArticleSpaceCategoryEntity> articleSpaceCategoryEntities) {
        final Set<String> categorySlugs =
                articleSpaceCategoryEntities.stream()
                        .map(ArticleSpaceCategoryEntity::getCategorySlug)
                        .collect(Collectors.toSet());

        final List<TermEntity> categories = postRepository.findCategoryBySlug(categorySlugs);
        return categories.stream().collect(Collectors.toMap(TermEntity::getSlug, Function.identity()));
    }

    private static ArticleSpaceResponse getSpaceResponse(
            @NotNull final ArticleSpaceEntity space,
            @Nullable final Collection<ArticleSpaceCategoryEntity> categoryEntities,
            @NotNull final Map<String, TermEntity> categoryMap) {
        if (CollectionUtils.isEmpty(categoryEntities)) {
            return ArticleSpaceResponse.from(space.getId(), space.getTitle(), List.of());
        }

        final List<ArticleSpaceResponse.Category> categoriesList =
                categoryEntities
                        .stream()
                        .filter(x -> categoryMap.containsKey(x.getCategorySlug()))
                        .map(x -> {
                            final TermEntity termEntity = categoryMap.get(x.getCategorySlug());
                            final String categoryName =
                                    StringUtils.isBlank(x.getCategoryName()) ?
                                            termEntity.getName().trim() : x.getCategoryName().trim();
                            return ArticleSpaceResponse.Category.from(termEntity.getId(), categoryName);
                        })
                        .filter(Objects::nonNull)
                        .toList();

        return ArticleSpaceResponse.from(space.getId(), space.getTitle(), categoriesList);
    }

    @Cacheable(value = "post_spaces", key = "'space_' + #spaceId + '_' + #language")
    public ArticleSpaceResponse getSpace(Long spaceId,
                                         @NotNull String language) throws AppException {
        final ArticleSpaceEntity articleSpaceEntity =
                articleSpaceRepository.findById(spaceId)
                        .orElseThrow(() -> new AppException(ErrorCode.SPACE_NOT_FOUND));

        final List<ArticleSpaceCategoryEntity> articleSpaceCategoryEntities =
                articleSpaceCategoryRepository.findAllEnableBySpaceAndLanguage(spaceId, language);

        final Map<String, TermEntity> categoryMap = getCategoryMap(articleSpaceCategoryEntities);

        return getSpaceResponse(articleSpaceEntity, articleSpaceCategoryEntities, categoryMap);
    }

    @Cacheable(value = "posts", key = "(#categoryId != null ? 'category_' + #categoryId : 'all_posts')")
    public List<PostResponse> findAllByCategory(@NotNull Long categoryId) {
        final List<Post> postList = postRepository
                .findByCategoryId(categoryId, List.of(PostStatus.PUBLISH,
                        PostStatus.FUTURE,
                        PostStatus.PRIVATE));

        return postList.stream().map(x -> PostResponse.from(x, false)).toList();
    }

    @Cacheable(value = "post_detail", key = "#postId")
    public PostResponse findById(@NotNull Long postId) throws AppException {
        return postRepository.findById(postId)
                .map(x -> PostResponse.from(x, true))
                .orElseThrow(() -> new AppException(ErrorCode.POST_NOT_FOUND));
    }
}
