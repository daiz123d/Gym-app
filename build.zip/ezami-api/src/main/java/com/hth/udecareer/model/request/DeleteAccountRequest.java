package com.hth.udecareer.model.request;

import lombok.Data;

@Data
public class DeleteAccountRequest {
    private String confirmationText;
}
