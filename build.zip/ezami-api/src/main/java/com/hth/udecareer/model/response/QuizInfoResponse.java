package com.hth.udecareer.model.response;

import static com.hth.udecareer.utils.HtmlUtil.processHtml;

import java.io.Serializable;
import java.util.List;

import com.hth.udecareer.enums.QuizType;
import com.hth.udecareer.model.dto.QuizDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QuizInfoResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String slug;

    private Integer timeLimit;

    private Long questions;

    private Integer passingPercentage;

    private Integer answeredQuestions;

    private String name;

    private Long postId;

    private String postContent;

    private String postTitle;

    private Integer showExplain;

    private List<QuestionResponse> questionList;

    private QuizType quizType;

    public static QuizInfoResponse from(final QuizDto quizDto,
                                        final List<QuestionResponse> questionResponseList) {
        return builder()
                .id(quizDto.getId())
                .slug(quizDto.getSlug())
                .timeLimit(quizDto.getTimeLimit())
                .name(quizDto.getName())
                .postId(quizDto.getPostId())
                .postContent(processHtml(quizDto.getPostContent()))
                .postTitle(quizDto.getPostTitle())
                .questionList(questionResponseList)
                .showExplain(1)
                .quizType(quizDto.getQuizType())
                .build();
    }

    public static QuizInfoResponse from(final QuizDto quizDto) {
        return builder()
                .id(quizDto.getId())
                .slug(quizDto.getSlug())
                .timeLimit(quizDto.getTimeLimit())
                .name(quizDto.getName())
                .postId(quizDto.getPostId())
                .postContent(processHtml(quizDto.getPostContent()))
                .postTitle(quizDto.getPostTitle())
                .questionList(List.of())
                .showExplain(1)
                .quizType(quizDto.getQuizType())
                .build();
    }
}
