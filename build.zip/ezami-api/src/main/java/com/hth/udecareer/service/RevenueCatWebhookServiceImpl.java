package com.hth.udecareer.service;

import com.hth.udecareer.entities.User;
import com.hth.udecareer.entities.UserPurchasedEntity;
import com.hth.udecareer.model.dto.RevenueCatWebhookDto;
import com.hth.udecareer.repository.UserPurchasedRepository;
import com.hth.udecareer.repository.UserRepository;
import com.hth.udecareer.service.Impl.RevenueCatWebhookService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Objects;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class RevenueCatWebhookServiceImpl implements RevenueCatWebhookService {
    private final UserPurchasedRepository userPurchasedRepository;
    private final UserRepository userRepository;

    @Value("${revenueCat.webhookSecret:}")
    private String webhookSecret;


    private String extractEmail(RevenueCatWebhookDto.Event event) {
        if (event.getSubscriberAttributes() != null && event.getSubscriberAttributes().getEmail() != null) {
            return event.getSubscriberAttributes().getEmail().getValue();
        }

        return null;
    }

    private String mapProductToCategoryCode(RevenueCatWebhookDto.Event event) {

        if (event.getEntitlementIds() != null && event.getEntitlementIds().length > 0) {
            String entitlement = event.getEntitlementIds()[0];
            if (entitlement.startsWith("ez_")) {
                return entitlement.substring(3);
            }
        }

        return null;
    }
    private LocalDateTime millisToLocalDateTime(Long millis) {
        return LocalDateTime.ofInstant(
                Instant.ofEpochMilli(millis),
                ZoneId.systemDefault()
        );
    }
    private void handlePurchaseEvent(String email, String categoryCode, RevenueCatWebhookDto.Event event) {
        log.info("Handle purchase event: email={}, category={}", email, categoryCode);

        Optional<User> optionalUser = userRepository.findByEmail(email);
        if (optionalUser.isEmpty()) {
            log.warn("User not found for email: {}, skipping webhook", email);
            return;
        }
        User user = optionalUser.get();

        UserPurchasedEntity entity = userPurchasedRepository
                .findAllByUserIdOrUserEmail(user.getId(), email)
                .stream()
                .filter(e -> categoryCode.equals(e.getCategoryCode()))
                .findFirst()
                .orElse(new UserPurchasedEntity());


        entity.setUserId(user.getId());
        entity.setUserEmail(email);
        entity.setCategoryCode(categoryCode);
        entity.setIsPurchased(1);


        if (event.getPurchasedAtMs() != null) {
            entity.setFromTime(millisToLocalDateTime(event.getPurchasedAtMs()));
        } else {
            entity.setFromTime(LocalDateTime.now());
        }

        if (event.getExpirationAtMs() != null) {
            entity.setToTime(millisToLocalDateTime(event.getExpirationAtMs()));
        } else {

            entity.setToTime(null);
        }

        userPurchasedRepository.save(entity);
        log.info("Saved UserPurchasedEntity: userId={}, category={}, expiresAt={}",
                user.getId(), categoryCode, entity.getToTime());
    }
    private void handleCancellationEvent(String email, String categoryCode, RevenueCatWebhookDto.Event event) {
        log.info("Handle cancellation event: email={}, category={}", email, categoryCode);

        Optional<User> optionalUser = userRepository.findByEmail(email);
        if (optionalUser.isEmpty()) {
            return;
        }
        User user = optionalUser.get();

        userPurchasedRepository
                .findAllByUserIdOrUserEmail(user.getId(), email)
                .stream()
                .filter(e -> categoryCode.equals(e.getCategoryCode()))
                .findFirst()
                .ifPresent(entity -> {
                    entity.setIsPurchased(0);
                    userPurchasedRepository.save(entity);
                    log.info("Updated UserPurchasedEntity as cancelled: userId={}, category={}",
                            user.getId(), categoryCode);
                });
    }

    private void handleUncancellationEvent(String email, String categoryCode, RevenueCatWebhookDto.Event event) {
        log.info("Handle uncancellation event: email={}, category={}", email, categoryCode);

        handlePurchaseEvent(email, categoryCode, event);
    }
    @Override
    @Transactional()
    public void processWebhookEvent(RevenueCatWebhookDto.WebhookEvent webhookEvent) {
        final RevenueCatWebhookDto.Event event = webhookEvent.getEvent();
        log.info("Processing RevenueCat webhook event: type={}, id={}, appUserId={}",
                event.getType(), event.getId(), event.getAppUserId());
        try{
            String email = extractEmail(event);
            if (email == null || email.isEmpty()) {
                log.warn("Cannot extract email from webhook event: {}", event.getId());
                return;
            }
            String categoryCode = mapProductToCategoryCode(event);
            if (categoryCode == null) {
                log.warn("Cannot map product to category code: productId={}", event.getProductId());
                return;
            }
            switch (event.getType()) {
                case "INITIAL_PURCHASE":
                case "RENEWAL":
                    handlePurchaseEvent(email, categoryCode, event);
                    break;

                case "CANCELLATION":
                case "EXPIRATION":
                case "BILLING_ISSUE":
                    handleCancellationEvent(email, categoryCode, event);
                    break;

                case "UNCANCELLATION":
                    handleUncancellationEvent(email, categoryCode, event);
                    break;

                default:
                    log.info("Event type {} not handled, skipping", event.getType());
            }

        }
        catch (Exception ex) {
            log.error("Error processing webhook event: {}", event.getId(), ex);
            throw ex;
        }
    }

    @Override
    public boolean verifyWebhookSignature(String payload, String signature) {
        if (webhookSecret == null || webhookSecret.isEmpty()) {
            log.warn("Webhook secret not configured, skipping signature verification");
            return true;
        }

        try {
            Mac hmac = Mac.getInstance("HmacSHA256");
            SecretKeySpec secretKey = new SecretKeySpec(webhookSecret.getBytes(), "HmacSHA256");
            hmac.init(secretKey);

            byte[] hash = hmac.doFinal(payload.getBytes());
            String calculatedSignature = Base64.getEncoder().encodeToString(hash);

            return calculatedSignature.equals(signature);
        } catch (Exception e) {
            log.error("Error verifying webhook signature", e);
            return false;
        }
    }
}
