package com.hth.udecareer.controllers;

import java.security.Principal;
import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hth.udecareer.annotation.ApiPrefixController;
import com.hth.udecareer.exception.AppException;
import com.hth.udecareer.model.request.SubmitAnswerRequest;
import com.hth.udecareer.model.response.CategoryResponse;
import com.hth.udecareer.model.response.QuizInfoResponse;
import com.hth.udecareer.model.response.QuizResponse;
import com.hth.udecareer.model.response.SubmitAnswerResponse;
import com.hth.udecareer.service.QuizCategoryService;
import com.hth.udecareer.service.QuizMasterService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@ApiPrefixController
@RequiredArgsConstructor
@Tag(name = "Quiz Management (Protected)")
@SecurityRequirement(name = "bearerAuth")
public class QuizController {

    private final QuizMasterService quizMasterService;
    private final QuizCategoryService quizCategoryService;

    @Operation(
            summary = "Tìm kiếm quiz", 
            description = """
                    **Tìm kiếm danh sách quiz theo danh mục hoặc loại bài test**
                    
                    API này trả về danh sách các quiz/bài kiểm tra dựa trên các bộ lọc:
                    - **category**: Mã danh mục (vd: "toeic-reading", "toeic-listening")
                    - **typeTest**: Loại test (vd: "full", "mini", "part1", "part2")
                    
                    **Tham số:**
                    - Có thể truyền cả 2 tham số, 1 tham số, hoặc không tham số nào
                    - Không truyền tham số = lấy tất cả quiz
                    
                    **Response:**
                    - Danh sách quiz với thông tin cơ bản
                    - Bao gồm thống kê nếu user đã làm bài (answeredQuestions, percentage, pass, etc.)
                    
                    **Yêu cầu:**
                    - Phải có JWT token hợp lệ
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Tìm thấy danh sách quiz"),
            @ApiResponse(responseCode = "401", description = "Chưa xác thực - Token không hợp lệ hoặc thiếu", content = @Content),
            @ApiResponse(responseCode = "403", description = "Không có quyền truy cập", content = @Content),
            @ApiResponse(responseCode = "400", description = "Tham số không hợp lệ", content = @Content),
            @ApiResponse(responseCode = "default",
                    description = "Lỗi không mong đợi",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
    })
    @GetMapping("/quiz")
    public List<QuizResponse> searchQuiz(
            @io.swagger.v3.oas.annotations.Parameter(hidden = true) Principal principal,
            @io.swagger.v3.oas.annotations.Parameter(
                    description = "Mã danh mục quiz (tùy chọn). Ví dụ: 'toeic-reading', 'toeic-listening'",
                    example = "toeic-reading",
                    required = false
            )
            @RequestParam(value = "category", required = false) String category,
            @io.swagger.v3.oas.annotations.Parameter(
                    description = "Loại bài test (tùy chọn). Ví dụ: 'full' (full test), 'mini' (mini test), 'part1', 'part2', etc.",
                    example = "full",
                    required = false
            )
            @RequestParam(value = "typeTest", required = false) String typeTest)
            throws AppException {
        log.info("searchQuiz: user {}, category {}, typeTest {}", principal.getName(), category, typeTest);
        return quizMasterService.searchQuiz(principal.getName(), category, typeTest);
    }

    @Operation(
            summary = "Lấy tất cả danh mục quiz", 
            description = """
                    **Lấy danh sách tất cả các danh mục quiz có sẵn**
                    
                    API này trả về tất cả các danh mục quiz/bài kiểm tra trong hệ thống.
                    
                    **Response bao gồm:**
                    - Thông tin danh mục (code, title, header, imageUri)
                    - Số lượng bài test trong mỗi danh mục (numFullTest, numMiniTest)
                    - Thông tin mua hàng của user (purchasedInfo)
                    - Mã offer/entitlement từ RevenueCat (nếu có)
                    
                    **Use cases:**
                    - Hiển thị danh sách danh mục trên trang chủ
                    - Cho phép user chọn danh mục để xem quiz
                    - Hiển thị trạng thái mua/chưa mua của từng danh mục
                    
                    **Yêu cầu:**
                    - Phải có JWT token hợp lệ
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lấy danh sách danh mục thành công"),
            @ApiResponse(responseCode = "401", description = "Chưa xác thực - Token không hợp lệ hoặc thiếu", content = @Content),
            @ApiResponse(responseCode = "403", description = "Không có quyền truy cập", content = @Content),
            @ApiResponse(responseCode = "default",
                    description = "Lỗi không mong đợi",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
    })
    @GetMapping("/quiz/category")
    public List<CategoryResponse> getAllCategory(
            @io.swagger.v3.oas.annotations.Parameter(hidden = true) Principal principal) throws AppException {
        log.info("getAllCategory: user {}", principal.getName());
        return quizCategoryService.findAll(principal.getName());
    }


    @Operation(
            summary = "Lấy chi tiết quiz theo ID", 
            description = """
                    **Lấy thông tin chi tiết của một quiz cụ thể, bao gồm tất cả câu hỏi**
                    
                    API này trả về toàn bộ thông tin của một quiz để user có thể bắt đầu làm bài:
                    
                    **Response bao gồm:**
                    - Thông tin quiz: tên, thời gian, số câu hỏi
                    - **Tất cả câu hỏi** trong quiz với các đáp án
                    - Cấu trúc phân nhóm (groups, parts, types) nếu có
                    - Thống kê lần làm trước (nếu user đã làm)
                    
                    **Use cases:**
                    - User bấm vào một quiz để bắt đầu làm bài
                    - Hiển thị trang làm quiz với tất cả câu hỏi
                    - Review lại kết quả lần làm trước
                    
                    **Lưu ý:**
                    - Response có thể rất lớn (nhiều câu hỏi)
                    - Nên cache ở client side
                    - Kiểm tra quyền truy cập (purchased) ở backend
                    
                    **Yêu cầu:**
                    - Phải có JWT token hợp lệ
                    - User phải có quyền truy cập quiz (đã mua hoặc miễn phí)
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lấy chi tiết quiz thành công"),
            @ApiResponse(responseCode = "401", description = "Chưa xác thực - Token không hợp lệ hoặc thiếu", content = @Content),
            @ApiResponse(responseCode = "403", description = "Không có quyền truy cập - Chưa mua quiz này", content = @Content),
            @ApiResponse(responseCode = "404", description = "Không tìm thấy quiz với ID này", content = @Content),
            @ApiResponse(responseCode = "default",
                    description = "Lỗi không mong đợi",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
    })
    @GetMapping("/quiz/{quizId}")
    public QuizInfoResponse getQuizInfo(
            @io.swagger.v3.oas.annotations.Parameter(hidden = true) Principal principal,
            @io.swagger.v3.oas.annotations.Parameter(
                    description = "ID của quiz cần lấy thông tin",
                    required = true,
                    example = "123"
            )
            @PathVariable("quizId") Long quizId) throws Exception {
        log.info("getQuizInfo: user {}, quizId {}", principal.getName(), quizId);
        return quizMasterService.getQuizInfo(principal.getName(), quizId);
    }

    @Operation(
            summary = "Nộp bài quiz", 
            description = """
                    **Nộp câu trả lời của user và nhận kết quả chấm điểm**
                    
                    API này xử lý việc nộp bài quiz và trả về kết quả chi tiết.
                    
                    **Request body:**
                    - Danh sách câu trả lời của user (questionId -> answerId/answerText)
                    - Thời gian bắt đầu và kết thúc (optional, để tính thời gian làm bài)
                    
                    **Response bao gồm:**
                    - Điểm số tổng (totalScore, percentage)
                    - Số câu đúng/sai (correctAnswers, wrongAnswers)
                    - Trạng thái đạt/không đạt (pass)
                    - Chi tiết từng câu (đúng/sai, đáp án đúng)
                    - Ranking/percentile (nếu có)
                    
                    **Xử lý:**
                    - Chấm điểm tự động
                    - Lưu kết quả vào database
                    - Cập nhật thống kê user
                    - Tính toán ranking
                    
                    **Lưu ý:**
                    - Mỗi lần submit tạo một record mới (cho phép làm lại)
                    - Giữ lại lịch sử tất cả các lần làm
                    
                    **Yêu cầu:**
                    - Phải có JWT token hợp lệ
                    - User phải có quyền làm quiz này
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Nộp bài thành công, kết quả được trả về"),
            @ApiResponse(responseCode = "400", description = "Định dạng câu trả lời không hợp lệ", content = @Content),
            @ApiResponse(responseCode = "401", description = "Chưa xác thực - Token không hợp lệ hoặc thiếu", content = @Content),
            @ApiResponse(responseCode = "403", description = "Không có quyền làm quiz này", content = @Content),
            @ApiResponse(responseCode = "404", description = "Không tìm thấy quiz với ID này", content = @Content),
            @ApiResponse(responseCode = "default",
                    description = "Lỗi không mong đợi",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
    })
    @PostMapping("/quiz/{quizId}")
    public SubmitAnswerResponse submitAnswerData(
            @io.swagger.v3.oas.annotations.Parameter(hidden = true) Principal principal,
            @io.swagger.v3.oas.annotations.Parameter(
                    description = "ID của quiz đang nộp bài",
                    required = true,
                    example = "123"
            )
            @PathVariable("quizId") Long quizId,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Danh sách câu trả lời của user",
                    required = true
            )
            @RequestBody SubmitAnswerRequest request) throws Exception {
        log.info("submitAnswerData: user {}, quizId {}", principal.getName(), quizId);
        return quizMasterService.submitAnswer(principal.getName(), quizId, request);
    }
}