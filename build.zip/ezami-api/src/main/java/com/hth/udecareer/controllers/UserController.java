package com.hth.udecareer.controllers;

import java.security.Principal;

import javax.validation.constraints.NotNull;
import javax.validation.Valid;

import com.hth.udecareer.model.request.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hth.udecareer.annotation.ApiPrefixController;
import com.hth.udecareer.exception.AppException;
import com.hth.udecareer.model.response.UserResponse;
import com.hth.udecareer.service.UserService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@ApiPrefixController
@RequiredArgsConstructor
@Tag(name = "User Account Management")
public class UserController {
        private final UserService userService;

        @Operation(summary = "Lấy thông tin người dùng hiện tại", description = """
                        **Lấy thông tin profile của người dùng đang đăng nhập**

                        API này trả về thông tin cá nhân của người dùng hiện tại dựa vào JWT token.

                        **Yêu cầu:**
                        - Phải có JWT token hợp lệ trong header Authorization

                        **Trả về:**
                        - username: Tên đăng nhập (tạo tự động từ email)
                        - email: Địa chỉ email
                        - displayName: Tên hiển thị
                        - niceName: Tên thân thiện
                        - userUrl: URL website cá nhân (nếu có)
                        """)
        @ApiResponses(value = {
                        @ApiResponse(responseCode = "200", description = "Lấy thông tin thành công"),
                        @ApiResponse(responseCode = "401", description = "Chưa xác thực - Token không hợp lệ hoặc thiếu", content = @Content),
                        @ApiResponse(responseCode = "404", description = "Không tìm thấy người dùng", content = @Content),
                        @ApiResponse(responseCode = "default", description = "Lỗi không mong đợi", content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
        })
        @SecurityRequirement(name = "bearerAuth")
        @GetMapping("/user/info")
        public UserResponse getUserInfo(
                        @io.swagger.v3.oas.annotations.Parameter(hidden = true) Principal principal)
                        throws AppException {
                log.info("getUserInfo: user {}", principal.getName());
                return userService.findByEmail(principal.getName());
        }

        @Operation(summary = "Cập nhật thông tin người dùng (tất cả field optional)", description = """
                        Cập nhật thông tin profile của người dùng đang đăng nhập.

                        - Tất cả các trường trong request đều **optional**
                        - Chỉ các trường có giá trị khác null và khác chuỗi rỗng (sau khi trim) mới được cập nhật

                        Trường áp dụng (ghi vào entity `User`):
                        - `displayName`: nếu gửi sẽ dùng làm tên hiển thị
                        - `fullName`: alias của displayName; chỉ dùng khi `displayName` không được gửi
                        - `niceName`: cập nhật `user_nicename`
                        - `userUrl`: cập nhật `user_url` (avatar URL)

                        Trường bị bỏ qua (không cập nhật DB):
                        - `email`, `mobile`, `dob` (giữ để tương thích payload cũ)

                        Ví dụ payload hợp lệ:
                        ```json
                        { "fullName": "Nguyễn Văn A" }
                        ```

                        Ví dụ payload nâng cao:
                        ```json
                        {
                          "displayName": "Nguyễn Văn A",
                          "niceName": "nguyenvana",
                          "userUrl": "https://cdn.example.com/avatars/u123.png"
                        }
                        ```
                        """)
        @ApiResponses(value = {
                        @ApiResponse(responseCode = "200", description = "Cập nhật thành công"),
                        @ApiResponse(responseCode = "400", description = "Dữ liệu không hợp lệ", content = @Content),
                        @ApiResponse(responseCode = "401", description = "Chưa xác thực - Token không hợp lệ hoặc thiếu", content = @Content),
                        @ApiResponse(responseCode = "default", description = "Lỗi không mong đợi", content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
        })
        @SecurityRequirement(name = "bearerAuth")
        @PostMapping("/user/update")
        public void update(
                        @io.swagger.v3.oas.annotations.Parameter(hidden = true) Principal principal,
                        @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "Thông tin người dùng cần cập nhật", required = true) @Valid @RequestBody UpdateUserInfoRequest request)
                        throws AppException {
                log.info("userUpdate: user {}", principal.getName());
                userService.updateUserInfo(request, principal.getName());
        }

        @Operation(summary = "Xóa tài khoản người dùng", description = """
                        **Xóa vĩnh viễn tài khoản của người dùng hiện tại**

                        API này sẽ:
                        - Xóa hoàn toàn tài khoản người dùng khỏi hệ thống
                        - Xóa tất cả dữ liệu liên quan (quiz history, progress, etc.)
                        - Token hiện tại sẽ không còn hợp lệ sau khi xóa

                        **Yêu cầu:**
                        - Phải có JWT token hợp lệ

                        **Khuyến nghị:**
                        - Nên có dialog xác nhận trước khi gọi API này
                        - Thông báo rõ ràng cho người dùng về hậu quả
                        """)
        @ApiResponses(value = {
                        @ApiResponse(responseCode = "200", description = "Xóa tài khoản thành công"),
                        @ApiResponse(responseCode = "401", description = "Chưa xác thực - Token không hợp lệ hoặc thiếu", content = @Content),
                        @ApiResponse(responseCode = "default", description = "Lỗi không mong đợi", content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
        })
        @SecurityRequirement(name = "bearerAuth")
        @PostMapping("/user/delete")
        public void delete(
                        @io.swagger.v3.oas.annotations.Parameter(hidden = true) Principal principal,
                        @RequestBody(required = false) DeleteAccountRequest request)
                        throws AppException {
                log.info("userDelete: user {}", principal.getName());
                userService.deleteAccount(principal.getName(), request);
        }

        @Operation(summary = "Generate verification code (Authenticated)", description = "Sends a verification code to the authenticated user's email (e.g., for changing email).")
        @ApiResponses(value = {
                        @ApiResponse(responseCode = "200", description = "Code sent successfully"),
                        @ApiResponse(responseCode = "400", description = "Bad Request - Invalid type", content = @Content),
                        @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content),
                        @ApiResponse(responseCode = "default", description = "Unexpected error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
        })
        @SecurityRequirement(name = "bearerAuth")
        @PostMapping("/user/verification-code")
        public void generateVerificationCode(@NotNull Principal principal,
                        @Valid @NotNull @RequestBody VerificationRequest request) throws Exception {
                log.info("generateVerificationCode: user {}, type {}", principal.getName(), request.getType());
                userService.generateVerificationCode(principal.getName(), request.getType());
        }

        @Operation(summary = "Đổi mật khẩu", description = """
                        **Đổi mật khẩu cho người dùng đã đăng nhập**

                        API này cho phép người dùng thay đổi mật khẩu bằng cách cung cấp:
                        - Mật khẩu cũ (để xác thực)
                        - Mật khẩu mới (tối thiểu 8 ký tự)

                        **Yêu cầu:**
                        - Phải có JWT token hợp lệ
                        - Mật khẩu cũ phải chính xác
                        - Mật khẩu mới phải tối thiểu 8 ký tự

                        **Flow:**
                        1. Hệ thống xác minh mật khẩu cũ
                        2. Nếu đúng, cập nhật mật khẩu mới
                        3. Token hiện tại vẫn còn hiệu lực (không cần đăng nhập lại)

                        **Lỗi phổ biến:**
                        - OLD_PASSWORD_INCORRECT: Mật khẩu cũ không đúng
                        - INVALID_PASSWORD: Mật khẩu mới không đủ yêu cầu
                        """)
        @ApiResponses(value = {
                        @ApiResponse(responseCode = "200", description = "Đổi mật khẩu thành công"),
                        @ApiResponse(responseCode = "400", description = "Mật khẩu cũ sai hoặc mật khẩu mới không hợp lệ", content = @Content),
                        @ApiResponse(responseCode = "401", description = "Chưa xác thực - Token không hợp lệ hoặc thiếu", content = @Content),
                        @ApiResponse(responseCode = "default", description = "Lỗi không mong đợi", content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
        })
        @SecurityRequirement(name = "bearerAuth")
        @PostMapping("/user/change-pass")
        public void changePass(
                        @io.swagger.v3.oas.annotations.Parameter(hidden = true) Principal principal,
                        @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "Mật khẩu cũ và mật khẩu mới", required = true) @Valid @RequestBody ChangePassRequest request)
                        throws AppException {
                log.info("changePass: user {}", principal.getName());
                userService.changePass(request, principal.getName());
        }

        @Operation(summary = "Reset password (Forgot)", description = "Public API to reset a user's password using an email and a verification code.")
        @ApiResponses(value = {
                        @ApiResponse(responseCode = "200", description = "Password reset successfully"),
                        @ApiResponse(responseCode = "400", description = "Bad Request - Invalid email, code, or password", content = @Content),
                        @ApiResponse(responseCode = "404", description = "User not found", content = @Content),
                        @ApiResponse(responseCode = "default", description = "Unexpected error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = com.hth.udecareer.model.response.ApiResponse.class)))
        })

        @PostMapping("/user/reset-pass")
        public void resetPass(@Valid @RequestBody ResetPasswordRequest request) throws AppException {
                log.info("resetPass: user {}", request.getEmail());
                userService.resetPass(request);
        }
}