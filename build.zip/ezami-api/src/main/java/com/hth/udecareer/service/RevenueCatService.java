package com.hth.udecareer.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hth.udecareer.model.dto.RevenueCatSubscriberDto;
import com.hth.udecareer.setting.RevenueCatSetting;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.squareup.okhttp.ResponseBody;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class RevenueCatService {

    private final RevenueCatSetting revenueCatSetting;

    public Optional<RevenueCatSubscriberDto> getSubscriber(final String appUserId) throws IOException {
        final OkHttpClient client = new OkHttpClient();
        final ObjectMapper objectMapper = new ObjectMapper()
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        final Request request = new Request.Builder()
                .url("%s/%s/%s".formatted(
                        revenueCatSetting.getApiBaseUrl(),
                        revenueCatSetting.getEndpoints().getSubscribers(),
                        appUserId))
                .get()
                .addHeader("accept", "application/json")
                .addHeader("Authorization", "Bearer " + revenueCatSetting.getSecretApiKey())
                .build();

        final Response response = client.newCall(request).execute();
        if (response.isSuccessful()) {
            try (final ResponseBody responseBody = response.body()) {
                return Optional.of(objectMapper.readValue(responseBody.string(), RevenueCatSubscriberDto.class));
            }
        }
        return Optional.empty();
    }
}
