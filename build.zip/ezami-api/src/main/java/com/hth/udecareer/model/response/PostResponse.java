package com.hth.udecareer.model.response;

import com.hth.udecareer.entities.Post;
import com.hth.udecareer.utils.HtmlUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import javax.validation.constraints.NotNull;
// THÊM IMPORT NÀY
import java.io.Serializable;
import java.util.regex.Pattern;

@Data
@Builder
@Schema(description = "Thông tin bài viết/article")
public class PostResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final Pattern TABLE_PATTERN = Pattern.compile("(<table.*>)");
    
    @Schema(description = "ID duy nhất của bài viết", example = "123")
    public Long id;

    @Schema(description = "Tiêu đề bài viết", example = "Hướng dẫn học TOEIC hiệu quả")
    public String title;

    @Schema(description = "Tên (slug) của bài viết", example = "huong-dan-hoc-toeic-hieu-qua")
    public String name;

    @Schema(description = "Nội dung HTML của bài viết", example = "<p>Nội dung bài viết...</p>")
    private String content;

    @Schema(description = "Trạng thái bài viết", example = "PUBLISH", allowableValues = {"PUBLISH", "DRAFT", "PRIVATE"})
    private String status;

    @Schema(description = "Loại bài viết", example = "post")
    private String type;

    public static PostResponse from(@NotNull Post post, boolean showContent) {
        final String content = StringUtils.isBlank(post.getContent()) ? "<p></p>"
                : TABLE_PATTERN.matcher(post.getContent()).replaceAll("<table>");

        return builder()
                .id(post.getId())
                .title(post.getTitle())
                .name(post.getName())
                .content(showContent ? HtmlUtil.processHtml(content) : "")
                .status(post.getStatus().name())
                .type(post.getType())
                .build();
    }
}
