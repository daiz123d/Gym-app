package com.hth.udecareer.enums;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public enum ErrorCode {
    INVALID_KEY(9999,"Uncategorized error", HttpStatus.INTERNAL_SERVER_ERROR), // default

    INVALID_EMAIL(1001,"Email is not valid", HttpStatus.BAD_REQUEST),
    EMAIL_REQUIRED(1002,"Email is required", HttpStatus.BAD_REQUEST),
    PASSWORD_REQUIRED(1003,"Password is required", HttpStatus.BAD_REQUEST),
    USERNAME_REQUIRED(1004,"Username is required", HttpStatus.BAD_REQUEST),
    OLD_PASSWORD_REQUIRED(1005,"Old password is required", HttpStatus.BAD_REQUEST),
    INVALID_PASSWORD(1006,"Password must be at least {min} characters", HttpStatus.BAD_REQUEST),
    INVALID_CODE(1007,"Invalid verification code", HttpStatus.UNAUTHORIZED),
    INVALID_CONFIRMATION_CODE(1008,"Invalid confirmation code", HttpStatus.BAD_REQUEST),

    EMAIL_INFO_EXISTED(1009,"This email is already associated with an account", HttpStatus.BAD_REQUEST),
    OLD_PASSWORD_INCORRECT(1010,"Old password is incorrect", HttpStatus.BAD_REQUEST),
    PASSWORD_INCORRECT(1011,"Password is incorrect", HttpStatus.BAD_REQUEST),
    EXPIRE_CONFIRMATION_CODE(1012,"The confirmation code is expired", HttpStatus.BAD_REQUEST),

    INVALID_TYPE(1013,"Verification code type is required", HttpStatus.BAD_REQUEST),

    EMAIL_USER_NOT_FOUND(1014,"User not found with email", HttpStatus.NOT_FOUND),
    SPACE_NOT_FOUND(1015,"Space not found", HttpStatus.NOT_FOUND),
    POST_NOT_FOUND(1016,"Post not found", HttpStatus.NOT_FOUND),
    QUIZ_NOT_FOUND(1017,"Quiz not found", HttpStatus.NOT_FOUND),
    EMAIL_NOT_FOUND(1018,"Email not found. Please sign up first.", HttpStatus.NOT_FOUND),
    RESOURCE_NOT_FOUND(1019,"Resource not found", HttpStatus.NOT_FOUND),

    USER_DISABLED(1020,"User disabled. Please contact support for assistance", HttpStatus.FORBIDDEN),
    ACCESS_DENIED(1021,"Access denied", HttpStatus.FORBIDDEN),

    DUPLICATE_RESOURCE(1022,"Resource already exists", HttpStatus.CONFLICT),

    RATE_LIMIT_EXCEEDED(1023,"Rate limit exceeded", HttpStatus.TOO_MANY_REQUESTS),

    DEPENDENCY_ERROR(1024,"External dependency error", HttpStatus.SERVICE_UNAVAILABLE),

    INVALID_CREDENTIALS(1025,"Invalid credentials", HttpStatus.UNAUTHORIZED),
    INVALID_TOKEN(1026,"Invalid token", HttpStatus.UNAUTHORIZED),
    EXPIRED_TOKEN(1027,"Token has expired", HttpStatus.UNAUTHORIZED),

    GOOGLE_AUTH_EMAIL_MISSING(1028,"Failed to get email from Google", HttpStatus.BAD_REQUEST),
    GOOGLE_TOKEN_EXCHANGE_FAILED(1029,"Failed to exchange code for Google token", HttpStatus.BAD_REQUEST),
    GOOGLE_USERINFO_FETCH_FAILED(1030,"Failed to fetch user info from Google", HttpStatus.BAD_REQUEST),

    VALIDATION_ERROR(1031,"Validation error", HttpStatus.BAD_REQUEST),
    BUSINESS_LOGIC_ERROR(1032,"Business logic error", HttpStatus.BAD_REQUEST),
    INVALID_CONFIRMATION_TEXT(1033,"Confirmation text must be 'DELETE'", HttpStatus.BAD_REQUEST);

    private final int code;
    private final String message;
    private final HttpStatus httpStatus;

    ErrorCode(int code, String message, HttpStatus httpStatus) {
        this.code = code;
        this.message = message;
        this.httpStatus = httpStatus;
    }
}
