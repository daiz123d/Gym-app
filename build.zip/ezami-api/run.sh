nohup ./gradlew bootRun --args='--spring.profiles.active=release' &
